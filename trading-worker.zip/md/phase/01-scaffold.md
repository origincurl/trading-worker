# Phase 0 — Project Scaffold

> 컴파일 가능한 빈 NestJS 프로젝트. 실제 비즈니스 로직 없음.

## Goal
- `yarn install && yarn build` 통과
- `yarn start` 부팅 시 NestJS hello world 동작 (4002 포트)
- 폴더 구조가 architecture.md와 일치
- 경로 alias 동작

## 산출물

### 1. 패키지/설정
- `package.json` — trading-be 의존성 + 워커 추가분
  - 추가: `@nestjs/schedule`, `@nestjs/bullmq`, `bullmq`
  - scripts: `start`, `start:dev`, `build`, `lint`, `format`, `test`, `typecheck`
- `tsconfig.json` — trading-be 와 동일 base (`strict`, `experimentalDecorators`, `emitDecoratorMetadata`)
- `tsconfig.build.json`
- `nest-cli.json`
- `eslint.config.mjs` — trading-be flat config 차용
- `.prettierrc` — trading-be 동일
- `.gitignore` — node_modules, dist, .env.local, captures, *.local.*

### 2. 폴더 (빈 폴더는 `.gitkeep`)
```
src/
  main.ts                    # NestFactory + ROLES env stub (실제 동작은 Phase 1)
  app.module.ts              # 빈 모듈
  config/.gitkeep
  common/.gitkeep
  health/.gitkeep
  shared/
    persistence/.gitkeep
    cache/.gitkeep
    bus/.gitkeep
    event/.gitkeep
  external/.gitkeep
  admin/.gitkeep
  roles/
    collector/.gitkeep
    calculator/.gitkeep
    executor/.gitkeep
    detector/.gitkeep
migrations/.gitkeep
```

### 3. Path alias

`tsconfig.json` paths + `jest.moduleNameMapper`:
```
@common/*       → src/common/*
@config/*       → src/config/*
@health/*       → src/health/*
@shared/*       → src/shared/*
@external/*     → src/external/*
@admin/*        → src/admin/*
@roles/*        → src/roles/*
```

### 4. 최소 main.ts
- `NestFactory.create(AppModule)` 호출
- PORT env 읽어서 listen (기본 4002)
- `app.module.ts`는 imports: []

### 5. .vscode
- 이미 있는 `.vscode/` 유지
- 필요시 `launch.json`만 추가 (이번 phase 범위 아님)

## Out of scope
- env validation (Phase 1)
- DB / Redis / 외부 호출 (Phase 2)
- role module 내용 (Phase 5)

## 검증 체크리스트
- [ ] `yarn install` 성공
- [ ] `yarn build` 성공
- [ ] `yarn start` 부팅 + 4002 포트 listen
- [ ] `yarn lint` 통과
- [ ] `yarn typecheck` (또는 `tsc --noEmit`) 통과
- [ ] `import { X } from '@common/...'` 형태 import 동작 (테스트용 dummy 한 줄로 확인)
