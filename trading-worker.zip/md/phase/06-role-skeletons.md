# Phase 5 — 4 Role Skeletons

> milestone: 모든 role module이 부팅 가능 + ROLES env로 선택 동작.

## Goal
- 4개 role module 존재 (collector / calculator / executor / detector)
- 각 role에 trigger/usecase/service 폴더 + dummy 구현 1개씩
- `ROLES` env로 활성화 모듈 선택 부팅
- 부팅 후 각 role이 자신의 활성 상태를 `/health`에 노출
- calculator/detector는 external/vendor import 금지 (lint or 폴더 단위 격리)

## 산출물

### 공통 패턴 (각 role마다)
```
roles/{role}/
  {role}.module.ts
  trigger/
    scheduler/.gitkeep
    consumer/.gitkeep
    subscriber/.gitkeep
    controller/.gitkeep
  usecase/.gitkeep
  service/.gitkeep
  repository/.gitkeep
```

### collector (vendor 의존 O)
- `collector.module.ts`
  - imports: `[BrokerageModule]` (COLLECTOR_BROKERAGE_GATEWAY 사용)
- `trigger/scheduler/heartbeat.scheduler.ts` — 부팅 확인용 dummy cron (1분마다 로그)
- `usecase/heartbeat.usecase.ts` — dummy
- `service/collector-status.service.ts` — getStatus() 반환

### calculator (vendor 의존 X)
- `calculator.module.ts`
  - **imports에 BrokerageModule 절대 포함 금지**
- `trigger/consumer/.gitkeep` — Phase 7에서 채움
- `service/calculator-status.service.ts`

### executor (vendor 의존 O)
- `executor.module.ts`
  - imports: `[BrokerageModule]` (EXECUTOR_BROKERAGE_GATEWAY 사용)
- `service/executor-status.service.ts`

### detector (vendor 의존 X)
- `detector.module.ts`
  - imports: `[NotifyModule]`
  - **BrokerageModule import 금지**
- `service/detector-status.service.ts`

### app.module.ts (Phase 1에서 만든 것을 확장)
```ts
export class AppModule {
  static register(roles: Role[]): DynamicModule {
    const roleModules = [];
    if (roles.includes('collector')) roleModules.push(CollectorModule);
    if (roles.includes('calculator')) roleModules.push(CalculatorModule);
    if (roles.includes('executor')) roleModules.push(ExecutorModule);
    if (roles.includes('detector')) roleModules.push(DetectorModule);
    return {
      module: AppModule,
      imports: [ConfigModule, PersistenceModule, RedisModule, BusModule, HealthModule, ...roleModules],
    };
  }
}
```

### health.service.ts 확장
- `/health` response에 `activeRoles: string[]`, `shardInfo: { index, count }` 포함
- 각 role의 `XxxStatusService` 주입받아 ready 상태 집계

### 컴파일타임 격리 검사
- ESLint rule (또는 dependency-cruiser 같은 도구):
  - `src/roles/calculator/**` → `src/external/brokerage/**` import 금지
  - `src/roles/detector/**` → `src/external/brokerage/**` import 금지
  - `src/roles/{collector,calculator,executor,detector}/**` → 다른 role 폴더 import 금지

### scheduler/cron 통합
- `@nestjs/schedule` 활성화 (app.module 또는 role module에서 `ScheduleModule.forRoot()`)
- 각 role의 scheduler trigger는 자기 모듈에 등록

## 검증 체크리스트
- [ ] `ROLES=collector` 부팅 → CollectorModule만 load, 다른 모듈 instance 없음
- [ ] `ROLES=collector,calculator` 부팅 → 둘 다 load
- [ ] `ROLES=invalid` → boot 실패
- [ ] `/health` 응답에 `activeRoles` 정확히 표시
- [ ] calculator 폴더 안에서 brokerage import 시도 시 lint 또는 build 실패
- [ ] collector dummy scheduler 1분 후 로그 출력 확인
- [ ] 단일 role 부팅 시 다른 role 의존 모듈은 load 안 됨 (예: detector만 실행할 때 BrokerageModule load 금지)

## Milestone 도달
이 phase 완료 시점:
- 전체 4개 role 골격 완성
- ROLES env로 단일/다중/샤딩 토폴로지 코드 변경 없이 시도 가능
- 다음 단계는 각 role 내부 로직 채우기 (Phase 6~9)
