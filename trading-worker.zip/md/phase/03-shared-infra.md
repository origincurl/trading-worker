# Phase 2 — Shared Infrastructure

> 모든 role이 공유하는 persistence/cache/bus/event 기반. 진입점은 service 계층에서만.

## Goal
- TypeORM DataSource 부팅 + `/ready`에서 상태 노출
- ioredis 클라이언트 부팅 + key prefix 적용
- BusPublisher / BusConsumer 인터페이스 + Redis 구현체 (Pub/Sub, Streams)
- BullMQ wrapper
- Event base type (`Event<T>`, schemaVersion, eventId, occurredAt)

## 산출물

### shared/persistence/
- `persistence.module.ts` — `@Global()` TypeOrmModule.forRootAsync, naming strategy
- `base.entity.ts` — id (bigint or uuid), createdAt, updatedAt
- 워커는 자기 테이블만 소유. trading-be 테이블 직접 write 금지
- mock/production은 env로 분리 (`MARKET_ENV` 컬럼은 phase 6에서 추가)

### shared/cache/
- `redis.module.ts` — ioredis 클라이언트 provider (`REDIS_CLIENT` token)
- `redis-key.builder.ts` — `worker:{env}:{domain}:{key}` 규칙 + `assertSafeKeySegment`
- `latest-price.writer.ts` (skeleton만, Phase 6에서 collector 사용)
- `heartbeat.writer.ts`

### shared/bus/

#### 인터페이스
```ts
// shared/bus/bus.token.ts
export const BUS_PUBLISHER = Symbol('BUS_PUBLISHER');
export const BUS_STREAMS   = Symbol('BUS_STREAMS');
export const BUS_QUEUE     = Symbol('BUS_QUEUE');

// shared/bus/bus-publisher.interface.ts
export interface BusPublisher {
  publish<T>(channel: string, event: WorkerEvent<T>): Promise<void>;
}

// shared/bus/bus-streams.interface.ts
export interface BusStreams {
  produce<T>(stream: string, event: WorkerEvent<T>): Promise<string>; // entry id
  createConsumer<T>(opts: { stream, group, consumer }): BusStreamConsumer<T>;
}

// shared/bus/bus-queue.interface.ts
export interface BusQueue {
  enqueue<T>(queue: string, payload: T, opts?: { jobId?: string; delay?: number }): Promise<void>;
  createProcessor<T>(queue: string, handler: (job: Job<T>) => Promise<void>): BusQueueProcessor;
}
```

#### Redis 구현체
- `RedisBusPublisher` — `client.publish(channel, JSON.stringify(event))`
- `RedisBusStreams` — `XADD` / `XREADGROUP` / `XACK`. consumer-group 자동 생성.
- `BullMqBusQueue` — `@nestjs/bullmq` 활용. concurrency 설정 가능.

#### Trigger 진입점 (Phase 5에서 role이 사용)
- `bus/subscriber/redis-subscriber.base.ts` — 핸들러 등록 베이스
- `bus/consumer/streams-consumer.base.ts` — `XREADGROUP` 폴링 루프
- `bus/processor/bullmq-processor.base.ts` — `@Processor` 데코레이터 베이스

### shared/event/
- `worker-event.ts` — base type
  ```ts
  export interface WorkerEvent<T = unknown> {
    eventId: string;          // ulid
    eventType: string;        // 'market.tick' 등
    schemaVersion: number;
    occurredAt: string;       // ISO
    producer: { role: string; instanceId: string };
    marketEnv: 'mock' | 'production';
    payload: T;
  }
  ```
- `event-id.ts` — ulid 생성 (`ulid` 패키지 또는 자체 구현)
- `event.mapper.ts` — model ↔ event 변환 헬퍼

### key/channel 스키마 (architecture.md 표 참조)

| 종류 | 패턴 | 매체 |
|---|---|---|
| 시세 publish | `market.{env}.tick.{provider}.{symbol}` | Redis Pub/Sub |
| 호가창 publish | `market.{env}.orderbook.{provider}.{symbol}` | Redis Pub/Sub |
| 캔들 close | `market.{env}.candle-closed.{provider}.{symbol}.{interval}` | Redis Streams |
| 시그널 큐 | `bull:signal.detected:{env}` | BullMQ |
| 체결 stream | `account.{env}.fill` | Redis Streams |
| 경보 stream | `risk.{env}.alert` | Redis Streams |

## 의존 패키지 추가
- `ulid` 또는 `nanoid`
- `bullmq`, `@nestjs/bullmq`

## 검증 체크리스트
- [ ] `WORKER_DATABASE_URL` 비어 있을 때 부팅 + `/ready` degraded
- [ ] `WORKER_DATABASE_URL` 유효 시 TypeORM 연결 성공
- [ ] `REDIS_URL` 빈 값 시 in-memory client fallback, `/ready` degraded
- [ ] `RedisBusPublisher.publish` 호출 후 별도 subscriber로 수신 확인 (integration test)
- [ ] `RedisBusStreams.produce` + `createConsumer` round-trip (integration test)
- [ ] `WorkerEvent` 직렬화 후 deserialize 동일성
- [ ] key prefix가 모든 키에 자동 적용됨
