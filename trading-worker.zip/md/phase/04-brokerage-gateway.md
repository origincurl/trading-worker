# Phase 3 — External: Brokerage Gateway

> vendor-agnostic 추상화 + Kiwoom 첫 구현체. collector/executor 키 분리 DI.

## Goal
- `BrokerageGateway` interface 정의 (model 기준)
- `KiwoomBrokerageGateway` 구현 (가장 기본 메서드만 — Phase 6/8에서 확장)
- `KiwoomApiClient` (raw REST/WS)
- `COLLECTOR_BROKERAGE_GATEWAY` / `EXECUTOR_BROKERAGE_GATEWAY` 토큰 분리 주입
- vendor rate limiter (per-token)

## 산출물

### external/brokerage/
```
external/brokerage/
  brokerage.module.ts
  brokerage.token.ts                       # COLLECTOR_*, EXECUTOR_* 토큰
  gateway/
    brokerage.gateway.ts                   # interface only, model 기준
  service/
    brokerage-gateway.resolver.ts          # vendor 라우팅 (multi-vendor 대비)
    rate-limiter.service.ts                # per-token leaky bucket
  vendors/
    kiwoom/
      kiwoom-brokerage.gateway.ts          # impl
      kiwoom.api-client.ts                 # REST 호출
      kiwoom-ws.client.ts                  # WS 클라이언트 (skeleton)
      contract/
        request/
          place-order-request.contract.ts
          get-account-balance-request.contract.ts
          ...
        response/
          place-order-response.contract.ts
          get-account-balance-response.contract.ts
          ...
      auth/
        kiwoom-token.service.ts            # token issue/refresh
```

### interface 메서드 (Phase 3 범위 = 최소 시그니처만)
```ts
export interface BrokerageGateway {
  // collector 용
  getAccountBalance(input: GetAccountBalanceInput): Promise<AccountBalanceModel>;
  getPositions(input: GetPositionsInput): Promise<PositionModel[]>;
  // executor 용
  placeOrder(input: PlaceOrderInput): Promise<OrderAckModel>;
  cancelOrder(input: CancelOrderInput): Promise<OrderAckModel>;
  modifyOrder(input: ModifyOrderInput): Promise<OrderAckModel>;
}
```
- Phase 3에서는 시그니처와 throw-stub 구현만. 실제 호출은 Phase 6/8.

### token & DI

```ts
// brokerage.token.ts
export const COLLECTOR_BROKERAGE_GATEWAY = Symbol('COLLECTOR_BROKERAGE_GATEWAY');
export const EXECUTOR_BROKERAGE_GATEWAY  = Symbol('EXECUTOR_BROKERAGE_GATEWAY');
```

```ts
// brokerage.module.ts
@Module({
  providers: [
    {
      provide: COLLECTOR_BROKERAGE_GATEWAY,
      useFactory: (config: KiwoomConfig) => new KiwoomBrokerageGateway({
        apiClient: new KiwoomApiClient({
          appKey: config.collectorAppKey,
          appSecret: config.collectorAppSecret,
          rateLimitProfile: 'collector',
        }),
      }),
      inject: [KIWOOM_CONFIG],
    },
    {
      provide: EXECUTOR_BROKERAGE_GATEWAY,
      useFactory: (config: KiwoomConfig) => new KiwoomBrokerageGateway({
        apiClient: new KiwoomApiClient({
          appKey: config.executorAppKey,
          appSecret: config.executorAppSecret,
          rateLimitProfile: 'executor',
        }),
      }),
      inject: [KIWOOM_CONFIG],
    },
  ],
  exports: [COLLECTOR_BROKERAGE_GATEWAY, EXECUTOR_BROKERAGE_GATEWAY],
})
export class BrokerageModule {}
```

### Rate limiter
- 토큰별로 독립 인스턴스 (collector ≠ executor)
- leaky bucket or token bucket. RPS + concurrent 제한
- `acquire()` async → 한도 초과 시 wait or typed `RateLimitExceededError`
- BE control-plane의 rate-limit acquire(외부 권위)는 Phase 4에서 다룸. 여기서는 process-local 한정.

### 비협상
- collector key와 executor key가 같으면 boot-time 검증에서 throw (config validation)
- Kiwoom token issue 응답에 들어있는 secret은 절대 로깅 금지
- contract는 vendor 폴더 밖으로 노출 금지 (typeguard import 검사 lint rule 또는 review)

## 검증 체크리스트
- [ ] 두 토큰이 다른 ApiClient 인스턴스를 주입받음 (unit test로 확인)
- [ ] COLLECTOR_APP_KEY === EXECUTOR_APP_KEY 시 boot 실패
- [ ] Kiwoom 토큰 발급 정상 (mock 환경에서)
- [ ] rate limiter 한도 초과 시 typed error
- [ ] gateway 메서드 호출 시 model 반환 (contract 외부 노출 X)
- [ ] `redactSecrets`가 contract response에 포함된 token 필드 스크럽
