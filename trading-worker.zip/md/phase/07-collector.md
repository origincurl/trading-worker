# Phase 6 — Collector Internals (tick → live pubsub)

> milestone: vendor WS frame이 들어와서 `market.tick` Redis pub/sub 채널로 fan-out될 때까지의 happy-path 한 줄기.

## 범위 결정

trading-market-runtime의 collector 로직 전체(WS subscribe, frame dispatch, tick parse, candle build, DB persist, universe planner)를 한 phase에 흡수하는 것은 무리. Phase 6은 "**tick ingestion 한 줄기**" 만 책임진다. candle build / DB persist / orderbook / universe는 별도 phase로 분리.

### Phase 6 scope (in)
1. `KiwoomWsClient` skeleton을 실제 connect/subscribe/onMessage 구동 가능한 구현체로 채움
2. frame dispatcher + tick parser (Kiwoom REAL `0B` 시세 frame만) 흡수
3. `TradeTickEvent` 정규화 model + event 정의
4. `LatestPriceWriter`(Phase 2 산출물)와 `BusPublisher.publish('market.tick.{provider}.{marketEnv}.{symbol}')` 연결
5. collector trigger: `KiwoomTickSubscriber` (VendorWsSubscriber 계층)
6. 종목 구독 부트스트랩: env 또는 in-process 정적 목록에서 시작 (BE universe 연동은 out)

### Phase 6 scope (out, 후속 phase에서)
- **Phase 6.5**: orderbook (`0D`) frame parse + `market.orderbook` pubsub
- **Phase 6.6**: candle builder (1m) + `market.candle.closed` Streams produce + DB persist
- **Phase 6.7**: BE control-plane universe lease → 동적 종목 구독 갱신
- **Phase 6.8**: WS auto-reconnect + resubscribe + tick rejection 룰
- **Phase 6.9**: dead-letter Streams + `tick.parseWarnings` 모니터링

각 후속 phase는 Phase 6 happy-path 위에 한 책임씩 얹는 식. milestone마다 booting + smoke test 가능.

## Goal
- `ROLES=collector` 부팅 시 `KIWOOM_MARKET_ENV=mock` 으로 mock WS에 connect
- 정적 구독 종목 1~2개에 대해 시세체결 frame이 들어오면 `TradeTickEvent`로 정규화
- 정규화 결과를 Redis pubsub `market.tick.kiwoom.{marketEnv}.{symbol}` 채널과 LatestPriceWriter (Redis key `latest:price:{symbol}`)에 동시 fan-out
- `/health` 의 `roleStatuses.collector.detail`에 마지막 tick timestamp 표시
- DB write / candle build / orderbook 모두 미수행

## 산출물

### 1. shared/event 확장
`market.tick.event.ts` — wire 포맷 event. `WorkerEvent<MarketTickPayload>` 형태.
```ts
export interface MarketTickPayload {
  provider: 'kiwoom';
  marketEnv: 'mock' | 'production';
  symbol: string;
  market: 'KOSPI' | 'KOSDAQ' | 'KONEX' | 'NXT' | 'unknown' | null;
  sourceTs: string | null;   // ISO8601
  receivedAt: string;
  price: number | null;
  tradeVolume: number | null;
  cumulativeVolume: number | null;
  parseWarnings: string[];
}
```
- `shared/event/event-factory.ts`에 `createMarketTickEvent(payload)` 헬퍼 추가
- channel naming: `market.tick.{provider}.{marketEnv}.{symbol}` 으로 통일 (architecture.md §8 fan-out 경로 준수)

### 2. external/brokerage/vendors/kiwoom WS 채움
- `kiwoom-ws.client.ts` skeleton → 실제 구현
  - market-runtime의 `KiwoomWebSocketClient` 흡수
  - connect / send(LOGIN/REG/REMOVE) / onMessage / onClose / onError
  - `connectTimeoutMs`, `logFrames` 옵션 유지
  - `redactSecrets` 적용 (이미 `@common/util/redact-secrets.ts`)
- `KiwoomBrokerageGateway`에 `subscribeTicks(symbols)` / `unsubscribeTicks(symbols)` 메서드 추가 (interface도 확장)
  - 단, 이 메서드는 vendor 격리 원칙에 따라 **collector profile에서만** 동작. `assertProfile('collector')` guard
  - executor profile gateway에서는 NotImplementedError throw

### 3. collector 내부 계층
```
src/roles/collector/
  trigger/
    subscriber/
      kiwoom-tick.subscriber.ts          # VendorWsSubscriber. 부팅 시 gateway.subscribeTicks() 호출, onMessage 콜백을 usecase에 위임
  usecase/
    ingest-tick.usecase.ts               # frame → TickFrameMapper → MarketTickPayload → service.recordTick()
  service/
    market-tick.service.ts               # LatestPriceWriter + BusPublisher 호출. 마지막 수신 timestamp 캐싱
  mapper/
    kiwoom-tick.event-mapper.ts          # market-runtime의 frame dispatcher + tick parser 흡수, 0B만
  collector.module.ts                    # 위 providers + 기존 heartbeat 유지
```
- `MarketTickService.recordTick(payload)`:
  1. `LatestPriceWriter.write(symbol, payload)` — Redis hash + TTL
  2. `BUS_PUBLISHER.publish(channel, event)` — pubsub fan-out
  3. 내부 `lastTickAt` 갱신 (CollectorStatusService에서 노출)
- 기존 `HeartbeatScheduler`는 유지. ingest 흐름과는 별개.

### 4. CollectorStatusService 확장
```ts
getStatus(): RoleStatus {
  return {
    role: 'collector',
    ready: this.subscriber.isConnected(),
    detail: `subscribed=${this.subscriber.subscribedSymbols().length}, lastTickAt=${this.service.lastTickAt() ?? 'never'}`,
  };
}
```

### 5. 부트스트랩 종목 (정적, 후속 phase에서 동적으로 교체)
- 새 config: `collector.config.ts` (선택)
  - `COLLECTOR_BOOTSTRAP_SYMBOLS` (CSV, 예: `005930,000660`)
  - 비어 있으면 `KiwoomTickSubscriber`는 connect만 하고 구독 안 함 (warn log)

### 6. .env.example / .env.local 추가
```
COLLECTOR_BOOTSTRAP_SYMBOLS=005930,000660
```

## 흐름

```
[K KiwoomWsClient.connect()]
   ↓ onMessage(raw)
[KiwoomTickSubscriber.handleFrame]
   ↓ KiwoomTickEventMapper.fromFrame(raw, ctx)
[IngestTickUsecase.execute(NormalizedEvent)]
   ↓ if kind === 'trade-tick' && !blocking warnings
[MarketTickService.recordTick(payload)]
   ↓
   ├── LatestPriceWriter.write(symbol, payload)
   └── BUS_PUBLISHER.publish('market.tick.kiwoom.<env>.<symbol>', event)
```

dead-letter / parseWarnings 누적은 Phase 6.9에서 처리. Phase 6에서는 `logger.warn`로만 흘려도 OK.

## 검증 체크리스트
- [ ] `ROLES=collector` 부팅 → 외부 vendor WS에 connect 성공 (mock URL 기준)
- [ ] WS frame mock 주입 시 `TradeTickEvent` 정규화 (단위 테스트로 보장)
- [ ] LatestPriceWriter 값이 Redis에 기록 (smoke test, Redis 가용 시)
- [ ] `market.tick.kiwoom.mock.{symbol}` 채널 SUBSCRIBE 시 event 수신 (`redis-cli psubscribe 'market.tick.*'`)
- [ ] `/health` 응답에 `lastTickAt`이 시간 흐름에 따라 갱신
- [ ] `yarn typecheck`/`yarn lint`/`yarn build`/`yarn test` 통과
- [ ] redactSecrets로 WS 로그에 토큰 노출 없음 (verify 스크립트 1개 추가)

## 의존성
- Phase 2 (`LatestPriceWriter`, `BUS_PUBLISHER`) 존재 ✓
- Phase 3 (`KiwoomBrokerageGateway`, `KiwoomWsClient` skeleton) 존재 ✓
- Phase 5 (`CollectorModule`, `HeartbeatScheduler`) 존재 ✓

## 비협상
- collector key (`KIWOOM_COLLECTOR_APP_KEY`)만 사용. executor 토큰 절대 노출 금지
- WS connect 실패 시 worker는 죽지 않음. degraded 상태로 부팅 (Phase 6.8에서 reconnect 추가)
- BE control-plane은 universe 통보 외에 호출 없음 (Phase 6.7까지 정적 종목)
- 모든 token / secret은 redactSecrets 통과 후에만 로깅
- Phase 6에서는 DB write 절대 없음 (Phase 6.6 candle phase의 책임)

## Milestone 도달
이 phase 완료 시점:
- mock WS에서 시세 frame이 들어오면 BE/FE까지 라이브 시세 fan-out 가능 (BE WS gateway가 pubsub 구독만 하면 즉시 동작)
- candle / DB / orderbook 없이도 "라이브 시세 표시"라는 사용자 facing 가치 한 줄기 완성
- 후속 Phase 6.x로 candle/orderbook/universe/reconnect를 한 책임씩 얹어나감
