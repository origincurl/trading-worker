# Phase 4 — External: BE Control-Plane + Notify Gateway

> BE와의 HMAC-signed 통신 클라이언트, detector용 알림 채널 추상화.

## Goal
- BE control-plane client 동작 (credential lease, signal report, rate-limit acquire 등)
- HMAC-signed request (JCS canonicalize + SHA-256)
- NotifyGateway interface + Slack/Email 구현 (또는 stub)

## 산출물

### external/be-control-plane/
```
external/be-control-plane/
  be-control-plane.module.ts
  be-control-plane.token.ts
  client/
    be-control-plane.client.ts            # typed BE HTTP client
    be-control-plane.signer.ts             # JCS + HMAC
    be-control-plane.errors.ts             # 401/429/5xx typed
  contract/
    request/
      pickup-job-request.contract.ts       # chart backfill 등
      acquire-rate-limit-request.contract.ts
      report-signal-detected.contract.ts
      report-order-filled.contract.ts
      report-alert-raised.contract.ts
      lease-credential-request.contract.ts
    response/
      pickup-job-response.contract.ts
      rate-limit-acquire-response.contract.ts
      credential-lease-response.contract.ts
```

### 메서드 (최소)
```ts
export interface BeControlPlaneClient {
  // chart backfill
  pickupChartJob(input): Promise<PickupResult>;
  reportChartFetch(input): Promise<void>;

  // credential
  leaseCredential(input: { vendor; accountId; scope }): Promise<CredentialLeaseModel>;

  // rate-limit coordination
  acquireRateLimit(input: { endpoint; tokens }): Promise<AcquireResult>;
  reportRateLimit429(input): Promise<void>;

  // signals/events upstream
  reportSignalDetected(event: SignalDetectedEvent): Promise<void>;
  reportOrderFilled(event: OrderFilledEvent): Promise<void>;
  reportAlertRaised(event: AlertRaisedEvent): Promise<void>;
}
```

- 모든 호출은 `BeControlPlaneSigner`로 HMAC headers 추가
- response는 typed result union (`success | denied | invalid | server_error`)
- timeout / retry 정책은 client 자체에서 (BE 정책 위임 영역 제외)

### HMAC signer
- JCS canonicalize (Phase 1의 `@common/util/jcs.ts` 사용)
- HMAC-SHA256(payload + timestamp + nonce, secret)
- header: `X-Worker-Id`, `X-Timestamp`, `X-Nonce`, `X-Signature`
- nonce store는 BE 측 (replay 방지). 워커는 매번 새 nonce 생성

### BE 미구현 시 fallback
- `BeControlPlaneClient` interface는 그대로
- `MockBeControlPlaneClient` impl 추가 (NODE_ENV=development + `BE_CONTROL_PLANE_MOCK=true` 시 주입)
- mock은 in-memory로 모든 메서드에 합리적 default 응답 반환

### external/notify/
```
external/notify/
  notify.module.ts
  notify.token.ts                          # NOTIFY_GATEWAY
  gateway/
    notify.gateway.ts                      # interface
  service/
    notify-gateway.resolver.ts             # channel 종류로 라우팅
  vendors/
    slack/
      slack-notify.gateway.ts
      slack.api-client.ts
      contract/
    email/
      smtp-notify.gateway.ts
      smtp.api-client.ts
      contract/
    sms/                                   # skeleton만
      aligo-notify.gateway.ts
      aligo.api-client.ts
```

### NotifyGateway interface
```ts
export interface NotifyGateway {
  notify(input: {
    channel: NotifyChannelModel;        // { type, config }
    title: string;
    body: string;
    severity: 'info' | 'warning' | 'critical';
    metadata?: Record<string, string>;
  }): Promise<NotifyResultModel>;
}
```

- channel.type 으로 vendor 라우팅 (`slack` / `email` / `sms`)
- detector 도메인에서만 사용. 다른 role import 금지.

## env 추가
```
BE_CONTROL_PLANE_MOCK=false                 # true 시 mock client 주입
SLACK_DEFAULT_WEBHOOK_URL=                  # 알림 채널 설정 fallback (있을 경우)
SMTP_HOST=
SMTP_PORT=
SMTP_USER=
SMTP_PASS=
```

## 검증 체크리스트
- [ ] BE control-plane client가 mock 모드로 부팅 (`BE_CONTROL_PLANE_MOCK=true`)
- [ ] HMAC signer 출력이 BE 측 검증 알고리즘과 byte-identical (JCS 1차 통과)
- [ ] credential lease 호출 후 model 반환 (mock)
- [ ] NotifyGateway가 channel.type에 따라 slack / smtp impl 선택
- [ ] 401/429/5xx 시 typed error 반환 (throw 아님)
