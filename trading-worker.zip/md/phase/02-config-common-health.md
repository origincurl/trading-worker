# Phase 1 — Config + Common + Health + Main

> 환경변수 검증, ROLES 기반 동적 부팅, health 엔드포인트, 공통 유틸.

## Goal
- 잘못된 env로 부팅 시 명확한 에러로 거부
- `ROLES=collector` 부팅 시 collector role module만 import (Phase 5에서 실제 module이 채워진 후 효과 확인)
- `/live`, `/ready`, `/health` HTTP 응답
- HMAC signer, redactSecrets 등 공통 유틸 사용 가능

## 산출물

### config/
- `runtime.config.ts` — `RuntimeConfigDto` (PORT, WORKER_INSTANCE_ID, NODE_ENV, ROLES, SHARD_INDEX, SHARD_COUNT)
- `persistence.config.ts` — `WORKER_DATABASE_URL` 등
- `redis.config.ts` — `REDIS_URL`, `REDIS_KEY_PREFIX`, latest/heartbeat TTL
- `kiwoom.config.ts` — `KIWOOM_MARKET_ENV`, WS/REST URL, **COLLECTOR_*/EXECUTOR_* key 분리**
- `be-control-plane.config.ts` — `BE_CONTROL_PLANE_URL`, `BE_HMAC_SECRET`
- `config.module.ts` — `@Global()` `ConfigModule.forRoot` + `validate` 함수 (class-validator)
- env validation은 boot-time. 실패 시 명확한 메시지로 throw 후 process.exit(1)
- 동일 키 잘못된 mock/production 매치 등 cross-field 검증

### common/
- `error/` — 도메인 에러 클래스 (`DomainError`, `ValidationError`, `IntegrationError`)
- `filter/all-exception.filter.ts` — 글로벌 exception filter
- `util/redact-secrets.ts` — token/secret/app_key/Authorization 등 키 스크럽
- `util/safe-stringify.ts`
- `util/shard.ts` — `shouldHandle(key, shardIndex, shardCount)` 결정론적 hash
- `util/jcs.ts` — RFC 8785 JSON canonicalize (BE control-plane 통신용)
- `auth/hmac-signer.ts` — JCS + HMAC-SHA256 signer (runtime → BE)
- `auth/role-guard.ts` — 컴파일타임 role 가드는 모듈 import 차단으로 보장 (런타임 가드는 별도)

### health/
- `health.controller.ts` — `/live`, `/ready`, `/health`
- `health.service.ts` — DB/Redis ping, role activation status, shard info
- `health.module.ts`

### main.ts
- `loadRoles()` — env에서 `ROLES` CSV 파싱, 알 수 없는 값 throw
- `bootstrap()`:
  1. env validation
  2. `AppModule.register({ roles })` 동적 import
  3. global pipe (ValidationPipe whitelist:true, transform:true)
  4. global filter (AllExceptionFilter)
  5. Swagger `/docs` (NODE_ENV !== production일 때만, 또는 admin 인증 필요)
  6. listen(PORT)

### app.module.ts
- `AppModule.register(roles)` static method
- imports: ConfigModule, HealthModule, + role 별 conditional import
- 이 시점 role 모듈은 placeholder만 존재 (Phase 5에서 채움)

## env 신규 키 (`.env.example` / `.env.local` 추가)
```
NODE_ENV=development
ROLES=collector,calculator,executor,detector
WORKER_INSTANCE_ID=worker-local
SHARD_INDEX=
SHARD_COUNT=

# vendor key 분리 (KIWOOM_APP_KEY는 collector/executor 공용에서 분리)
KIWOOM_COLLECTOR_APP_KEY=
KIWOOM_COLLECTOR_APP_SECRET=
KIWOOM_EXECUTOR_APP_KEY=
KIWOOM_EXECUTOR_APP_SECRET=

# BE control-plane
BE_CONTROL_PLANE_URL=http://localhost:4000
BE_HMAC_SECRET=
```

기존 키 유지:
- `KIWOOM_APP_KEY`, `KIWOOM_APP_SECRET`, `KIWOOM_ACCESS_TOKEN` — 임시 호환 (Phase 6 마이그레이션 시 제거 검토)
- `MARKET_RUNTIME_DATABASE_URL` → `WORKER_DATABASE_URL` 으로 rename (이전 키도 fallback)
- `REDIS_URL` 유지
- `RUNTIME_SERVICE_HMAC_SECRET` → `BE_HMAC_SECRET` 별칭

## 검증 체크리스트
- [ ] `ROLES=unknown` → boot 실패
- [ ] `ROLES=collector` → 부팅 + `GET /health` 응답에 `roles: ['collector']`
- [ ] `KIWOOM_MARKET_ENV=production` + URL hostname 불일치 → boot 실패
- [ ] `SHARD_INDEX >= SHARD_COUNT` → boot 실패
- [ ] `GET /live` 200, `GET /ready` 200 (DB/Redis 미설정 시에도 graceful)
- [ ] `redactSecrets({ token: 'xyz' })` 결과에서 'xyz' 제거됨 (unit test)
