# trading-market-runtime — 재구축 스펙

키움(Kiwoom) 시장 데이터 수집 / 캔들 빌드 / 유니버스 관리 / 시그널 스캔을 담당하는 NestJS 런타임 서비스의 핵심 기능 스펙. `trading-be`(주문/리스크/인증 담당)와 분리된 **시장 데이터 워커 + 시그널 디텍터**.

---

## 1. 책임 경계 (가장 먼저 박는 못)

### 이 런타임이 하는 일

- 키움 WebSocket 라이프사이클 (connect / LOGIN / REG / REMOVE)
- 실시간 tick · orderbook 수집·파싱·정규화
- 최신가 캐시 (Redis)
- 1분봉 빌드 및 영속화 (`market_candles` Postgres)
- BE가 승인한 **유니버스 실행** (구독 plan 적용)
- 닫힌 캔들 기반 **시그널 후보 산출** (`SignalDetected` 레코드)
- 차트 REST 백필 워커 (BE 발급 lease 기반)
- 오픈 캔들 실시간 퍼블리시 (Redis)
- Health / metrics / 구조화 로그

### 이 런타임이 절대 하지 않는 일

- 브로커 주문 호출 (절대 금지)
- `OrderIntent` 생성 (draft도 금지)
- Kiwoom REST `order / cancel / modify` 호출
- 전략 파라미터의 권위 소유 (BE의 read-only 스냅샷만 소비)
- 유니버스 정책 결정 (BE 승인본 실행만)
- 최종 계좌 리스크 / 킬스위치
- 사용자 인증 / 계좌 소유권
- 브로커·데이터 공급자 credential 저장·회전 (BE가 lease로 발급)

### 세 가지 load-bearing 규칙

1. **시그널은 주문이 아니다.** 런타임은 `SignalDetected`만 발행. `OrderIntent`로 바꾸는 건 오직 BE.
2. **전략 파라미터는 BE 소유.** 런타임은 read-only 스냅샷만 소비.
3. **유니버스는 BE 승인본만.** 런타임은 캡 초과 거부는 가능하지만 유니버스 내용을 결정하지 않음.

---

## 2. 기술 스택

- **런타임**: Node.js 20 LTS
- **프레임워크**: NestJS 11 (Express 어댑터)
- **언어**: TypeScript 5.7+
- **패키지 매니저**: Yarn 1.x (`yarn.lock` 단일 소스 오브 트루스)
- **DB**: PostgreSQL (영속 캔들 저장)
- **캐시·pubsub**: Redis (ioredis)
- **WebSocket 클라이언트**: `ws`
- **검증**: class-validator / class-transformer
- **테스트**: Jest + ts-jest
- **API 문서**: `@nestjs/swagger` (/docs)
- **컨테이너**: Docker (제공)

---

## 3. 모듈 구조

```
src/
  main.ts                    # HTTP 서버 엔트리 (포트 4001 기본)
  verify-kiwoom-*.ts         # 키움 검증용 CLI 엔트리 (verify:ws, fields, index, fx, order)
  app.module.ts
  config/                    # 검증된 env (runtime / kiwoom / redis / postgres / verify / universe / chart-backfill)
  common/                    # 에러, exception filter
  health/                    # /live /ready /health
  kiwoom/
    client/                  # KiwoomWebSocketClient + factory
    messages/                # LOGIN / REG / REMOVE 빌더, realtime 타입
    security/                # redactSecrets / safeStringify
    verify/                  # 검증 시나리오 planner / runner
  market-data/               # 0B 파서, frame dispatcher, dead-letter
  candles/                   # Candle, KST 버킷, LatestStateCache, CandleBuilder
  redis/                     # RedisClient(인메모리+ioredis), key schema, LatestPriceWriter, HeartbeatWriter, OpenCandlePublisher
  candle-persistence/        # Postgres upsert (in-memory fallback 포함)
  orchestration/             # MarketDataPipelineService, HeartbeatScheduler
  universe/                  # UniverseSnapshot, StaticUniverseLoader, UniverseService, SubscriptionPlannerService
  signals/                   # SignalDetected, StrategyInstanceSnapshot, SignalScanner, dedupe
  chart-backfill/            # JCS canonicalizer, HMAC signer, BE control-plane client, KiwoomChartRestClient, mapper, worker, scheduler
  orders/                    # (배치 검증/리포트 전용. 실제 주문 호출 없음)
migrations/                  # 수동 적용 SQL (auto-migration 미사용)
```

### 경로 별칭 (Jest moduleNameMapper)

```
@common, @config, @health, @kiwoom, @redis-mod, @market-data,
@candles, @candle-persistence, @universe, @signals, @orders,
@chart-backfill
```

---

## 4. 핵심 기능 — Phase 별 정리

### Phase 1 — 런타임 스캐폴드

- HTTP 서버 부트
- env 검증 (boot-time, 실패 시 부트 거부)
- 헬스 엔드포인트
- Swagger UI `/docs`

### Phase 2 — 키움 WebSocket 검증 하네스

- 별도 CLI 엔트리 (`verify-kiwoom-ws.ts`). `start:dev`에서는 부트되지 않음.
- 시나리오: `connect-only`, `register-1-tick`, `register-100-tick`, `register-101-tick`, `multi-group`, `type-mix`, `multi-connection`
- 심볼 입력: `KIWOOM_VERIFY_SYMBOLS`(CSV) 또는 `KIWOOM_VERIFY_SYMBOLS_FILE`(JSON/라인)
- 안전: 토큰/시크릿 절대 로깅 금지, LOGIN/REG/REMOVE만 송신, 캡처는 gitignored 경로
- 결과 기록은 `docs/kiwoom-market-data-limits.md`에 측정/가정/미지 분리해서 누적

### Phase 3 — 프레임 파서 + 디스패처

- `0B` 실시간 타입 파서 (트레이드 틱)
- `dispatchKiwoomFrame` — 정상 라우팅 / 알 수 없는 타입은 dead-letter 카운터
- 캡처된 모의 REAL 프레임 픽스처로 검증

### Phase 4 — 인메모리 상태 + 캔들 빌더

- `LatestStateCache` — 심볼별 최신 상태
- `CandleBuilder` — 1분봉 빌드 (KST 분 경계), `rolledOver` 이벤트 발행
- 누적 거래량 sanity 체크 (`cumulative_volume_first/last/anomalies`)
- `hasBlockingWarnings()` 계약

### Phase 4.5 — Redis 실시간 캐시

키 스키마 (`assertSafeKeySegment`로 분리 보장):

| Key | Writer | TTL |
|---|---|---|
| `market:{env}:latest:{symbol}` | `LatestPriceWriter` | `REDIS_LATEST_TTL_SEC` (기본 60) |
| `market:{env}:heartbeat:{runtimeId}` | `HeartbeatWriter` | `REDIS_HEARTBEAT_TTL_SEC` (기본 30) |

부팅 정책:

- `REDIS_URL` 비어 있음 → 인메모리 폴백. `/ready`는 HTTP 503 `{status:'degraded', redis:'no-redis'}`
- Redis 연결 실패는 **부팅 non-fatal**. write는 typed error 반환, `/ready`가 상태 반영
- mock/production 키는 절대 공유 금지 (`marketEnv` 세그먼트로 분리)

**불변식**: `REDIS_HEARTBEAT_INTERVAL_SEC < REDIS_HEARTBEAT_TTL_SEC` (부팅 시 강제)

### Phase 5 — 파이프라인 orchestration

- `MarketDataPipelineService` — 순수 라우팅, 소켓 소유 안함. `attachTo(client)`로 주입
- 프레임 흐름:

```
frame → dispatchKiwoomFrame
        ├─ dead-letter   → 카운터
        └─ trade-tick    → LatestStateCache.update + CandleBuilder.ingest
                           ├─ cache.accepted     → LatestPriceWriter.write
                           └─ builder.rolledOver → CandlePersistenceService.persistClosedCandle
```

- `HeartbeatScheduler` — `setInterval` 기반, 부트 시 즉시 첫 tick, `onModuleDestroy`에서 `clearInterval`
- `flushOpenCandlesToPersistence()` — 셧다운/EOD에서 열린 캔들 영속화
- production 구독 토폴로지는 미측정이므로 자동 `attachTo` 안함. 컴포지션 루트가 결정.

### Phase 5.5 — Postgres 캔들 영속화

테이블: `market_candles` (런타임 단독 소유)

| Column | 비고 |
|---|---|
| `provider` | `'kiwoom'` |
| `market_env` | `'mock'` / `'production'` (NOT NULL) |
| `symbol` | 브로커 코드 (NOT NULL) |
| `interval_type` | `'1m'` |
| `candle_time` | KST 분 경계 timestamptz |
| `bucket_end` | `candle_time + 1 minute` |
| `market` | `KOSPI|KOSDAQ|KONEX|NXT` (nullable, 추후 resolver) |
| `stock_id` | bigint (nullable) |
| OHLC / volume / tick_count | builder 결과 |
| first/last_source_ts | source-time |
| cumulative_volume_first/last/anomalies | builder cumVol 체크 결과 |
| created_at / updated_at | 서비스 관리 |

- **Unique key**: `(provider, market_env, symbol, interval_type, candle_time)` 5개 모두 NOT NULL
- 영속화는 **닫힌 캔들 전용**. `closedBefore: now` write check로 강제
- `MARKET_RUNTIME_DATABASE_URL` 비어 있음 → 인메모리 폴백 + `/ready` degraded
- 마이그레이션은 수동: `psql "$URL" -f migrations/001_market_candles.sql`
- 실패 시 typed error 반환 + 파이프라인은 계속 진행 (`/ready` degraded로 반영)
- **identity scope: 심볼-레벨**. 동일 심볼 동일 KST 분은 1 row. 향후 venue-specific 필요 시 unique key 재논의.

### Phase 6 — Universe Manager (스냅샷 소비자)

- `UniverseSnapshot` 형태: `snapshotId / marketEnv / generatedAt / source ('be'|'file-bootstrap'|'test') / subscriptionSymbols / strategyUniverses`
- 한국 브로커 코드 검증: `^\d{6}$`
- `normalizeSymbols` — dedupe + sort, invalid 시 typed result
- `loadStaticUniverse` — JSON 파일 부트스트랩 (dev/mock/CI 전용, `source:'file-bootstrap'` 스탬프). Nest DI에 일부러 미등록.
- `UniverseService` — in-memory 액티브 상태 + Redis 캐시, `applySnapshot`만 변경 진입점
  - 노출 API: `applySnapshot` / `getActiveSnapshot` / `getActiveSymbols` / `getStats` (단일 심볼 mutate API 없음)
  - `canonicalizeSnapshot` — wrapper / 양쪽 top-level array / 모든 strategy scope / nested `symbols` 모두 deep-freeze
  - `generatedAt`은 freeze 불가능 → `getActiveSnapshot`은 매 호출 fresh `Date` 복사
- `SubscriptionPlannerService` — 결정론적 Kiwoom REG 그룹 plan. `subscriptionSymbols`만 받음 (strategy scope 분리)
- **production cap은 operator-committed**. `KIWOOM_MARKET_ENV=production`인데 `UNIVERSE_PER_CONNECTION_CAP` 미설정 시 부팅 거부. mock 200은 mock 전용 측정치이고 production으로 상속 안됨.
- multi-token / multi-app-key 샤딩 없음 (단일 connection plan).

Redis 키:

| Key | Writer | 비고 |
|---|---|---|
| `market:{env}:universe:active` | `UniverseService` | TTL `UNIVERSE_ACTIVE_TTL_SEC` (기본 86400). 매 applySnapshot에 refresh |
| `market:{env}:subscription:plan` | reserved | planner 출력 검사용 |

### Phase 7 — Signal Scanner (관측 전용)

- `SignalDetected` 필드: `signalId / strategyInstanceId / symbol / marketEnv / intervalType / candleTime / signalType / sideLabel / detectedAt / inputs` (provenance만)
- **금지 필드 14종** (top-level + `inputs` 모두 검사):
  ```
  quantity, size, orderPrice, executionPrice, limitPrice, targetPrice,
  accountId, account, position,
  orderIntent, orderId, brokerOrderId,
  riskDecision, killSwitchDecision
  ```
- `sideLabel`은 `-candidate` 접미사 강제 (`long-entry-candidate`, `long-exit-candidate`, `short-entry-candidate`, `short-exit-candidate`)
- `StrategyInstanceSnapshot` — read-only. `canonicalizeStrategySnapshot`이 deep-freeze + 심볼 정규화 + params shape 검증
- `buildSignalDedupeKey + computeSignalId` — 결정론적 SHA-256 prefix. 같은 candle+strategy+label = 같은 id
- `SignalScanner` 토이 구현 `PriceThresholdScanner`:
  - `direction:'above' + close >= threshold` → `long-entry-candidate`
  - `direction:'below' + close <= threshold` → `short-entry-candidate`
  - 그 외 → `no-signal/condition-not-met`
  - out-of-scope 심볼 / disabled / env mismatch / invalid candle / bad params → typed result (throw 안함)
- **파이프라인 미통합** (Phase 9에서 wiring). 인메모리 stub 주입 금지.
- 전략 타입은 discriminated `StrategyParams` 유니온 확장 가능.

### Phase 7.5 — Market Data Platform Design (doc-only)

- BE 소유: credential registry, endpoint-typed rate-limit, chart retention, coverage + backfill, chart serving model
- 코드 없음. 운영/소유권 lock 문서.

### Phase 7.6 / 7.7 — BE 스키마 (이 repo 아님)

- credential registry + capability + endpoint state
- coverage + backfill + rate-limit coordinator

### Phase 7.8 — 차트 REST 백필 워커

#### 설계 lock (7.8.0)

- pull-based job pickup
- per-job atomic locking (BE 측)
- HMAC-signed 런타임 → BE 리포트 인증
- BE-side rate-limit acquire RPC
- chart-REST-only scope (order/account/balance/position 메서드 없음)
- BE-owned retry policy
- auto cross-credential failover 없음

#### 7.8.2 — 런타임 surface (코드)

- **RFC 8785 JCS canonicalizer** (BE와 바이트 동일)
- **런타임 HMAC signer**
- **typed BE control-plane client** — HMAC-signed pickup / 6개 리포트 / rate-limit acquire+report-429
- **in-memory chart lease 모델** — pre-network 가드: scope mismatch, `lease.market_env != KIWOOM_MARKET_ENV`, `lease.expires_at <= now` 모두 typed error (브로커 URL 접근 전)
- **KiwoomChartRestClient.fetchCandles** — 차트 전용
  - 엔드포인트: `POST /api/dostk/chart`, `api-id: ka10080` (1분봉)
  - mock 호스트: `https://mockapi.kiwoom.com`
  - 요청 body: `{ stk_cd, tic_scope:'1', upd_stkpc_tp:'1' }`
  - 응답 파싱: `stk_min_pole_chart_qry`의 `cntr_tm, open_pric, high_pric, low_pric, cur_prc, trde_qty`
  - signed price string → absolute OHLC 정규화
  - **모든 메서드는 typed result union 반환. 예외 escape 금지.**
- **순수 mapper** — REST 응답 → Phase 5.5 input shape
- **outcome → report 헬퍼** — `redactSecrets`로 detail string scrub
- **lease bundle은 메모리 전용** — Redis/Postgres/로그/메트릭 레이블/에러 메시지/리포트 payload에 절대 등장 금지
- **env credential fallback 금지** — `KIWOOM_APP_KEY` / `KIWOOM_APP_SECRET` 으로 차트 호출 절대 안함

#### 7.8.3 — 워커 오케스트레이션

- `ChartBackfillWorkerService.tickOnce()` 흐름:
  ```
  pickup → BE rate-limit acquire → Kiwoom chart REST fetch
         → persist closed (Phase 5.5) → report outcome
  ```
- **typed `TickResult` 유니온**: `disabled / empty / pickup_failed / lease_invalid_reported / acquire_denied / invalid_job_range_reported / fetch_reported / persist_failed_reported / report_failed`. raw exception escape 없음.
- **closed-only invariant**: 워커가 `closedBefore: now`를 fetch에 강제. client는 `min(to, closedBefore)`, mapper는 `bucketEnd <= cutoff` 드랍.
- **acquire denied 시 브로커 호출/실패 리포트 모두 없음** — BE 재시도 정책 위임.
- **concurrency 1**. `ChartBackfillSchedulerService`가 `CHART_REST_BACKFILL_POLL_INTERVAL_MS` (기본 5s, 최소 250ms)로 호출. 재진입 fire는 큐잉 없이 드랍.
- lifecycle: `OnModuleInit`에서 enabled일 때만 시작 / `OnApplicationShutdown`에서 interval clear + in-flight 대기.
- coverage report는 **실제 받은 캔들 범위**(`first.bucketStart → last.bucketEnd`)로 보고. `ka10080`이 임의 from/to를 안 지키고 최근 봉을 반환하기 때문.
- 기본 `CHART_REST_BACKFILL_CLIENT_ENABLED=false`로 disabled 출하.

### Phase 7.9 — BE 차트 조회 API (이 repo 아님)

- `GET /v1/market-data/candles` BE 소유, DB 닫힌 캔들 + gap enqueue
- 런타임은 `market_candles` write만 소유

### Phase 7.10 — 차트 서빙 설계 (doc-only)

- FE는 BE만 통신 (REST 과거 + WS 라이브 오버레이)
- 런타임은 broker-facing 유지, FE 네트워크에서 주소 지정 안됨

### Phase 7.11 — 오픈 캔들 퍼블리셔 (런타임 측)

새 Redis surface:

| Surface | 키/채널 | 비고 |
|---|---|---|
| Open candle | `market:{env}:open-candle:{provider}:{symbol}:{intervalType}` | 매 accepted tick에 set. TTL=버킷길이+grace. 롤오버 시 삭제. |
| Sequence counter | `market:{env}:open-seq:{provider}:{symbol}:{intervalType}` | no TTL. `INCR`로 strict-monotonic. restart-safe. |
| Latest-tick pubsub | `market.{env}.latest-tick.{provider}.{symbol}.{intervalType}` | `LatestPriceWriter`가 live-axis `INCR` 성공 후 publish |
| Candle-closed pubsub | `market.{env}.candle-closed.{provider}.{symbol}.{intervalType}` | Phase 5.5 upsert **성공 후** publish |

Open candle payload:

- wire 필드: provider / marketEnv / symbol / intervalType / bucketStart / bucketEnd / OHLCV / tickCount / lastSourceTs / sequence / `isOpen:true`
- publisher 메타: `runtimeInstanceId` (Redis payload에만 존재. BE 게이트웨이가 FE 송출 전 제거)

규칙:

- **startup namespace cleanup**: 부트 시 본인 universe의 `market:{env}:open-candle:*` 스캔/삭제 (이전 인스턴스 잔여물 제거)
- **stale-key detection**: 본인이 안 쓴 키(`runtimeInstanceId` 불일치 또는 `bucketStart+bucketLength` 초과 TTL)는 만료까지 그대로 두고 덮어쓰지 않음 (다중 런타임 stomp 방지)
- pubsub은 **live fan-out 전용**, 절대 replay 소스 아님. 핸드셰이크 replay는 Postgres에서 합성
- **부분 실패 규칙**: BE 소비자가 `(provider, marketEnv, symbol, intervalType, bucketStart)`로 idempotent 중복 제거. 재발행 OK, 2PC 락 불필요
- 절대 금지: FE-facing socket, open candle의 DB write, Postgres NOTIFY/LISTEN, 오픈 캔들의 retroactive 백필

**Degraded mode**: `latest_tick / open_candle / closed_candle_notice` 세 sequenced 이벤트 모두 Redis `INCR` 성공에 gating. Redis 다운 시 어느 것도 흐르지 않음. 핸드셰이크 replay(Postgres)는 정상 동작 — Redis 복구 후 reconnect 시 gap 없음.

### Phase 7.11.1 — Latest-tick sequence stamping

- `LatestPriceWriter`가 open/close 이벤트와 동일한 restart-safe live-axis `INCR` 키 사용
- `latest:*` 페이로드에 sequence 저장
- 위 latest-tick pubsub publish

### Phase 7.12 — FE 통합 (이 repo 아님)

- FE는 REST 과거 strip + WS `latest_tick / open_candle / closed_candle_notice` 오버레이
- provisional backfill preview, reconnect/replay
- 런타임 직접 소켓 없음

### Phase 8 / 8.5 / 9 / 9.5 — 핸드오프 컨트랙트 (이 repo 미구현)

| Phase | 소유 | 추가 사항 |
|---|---|---|
| 8 | BE | 시그널 intake — 검증/dedupe/audit/persist. `OrderIntent` 없음, 리스크 게이트 없음 |
| 8.5 | BE | `OrderIntent` 모델 + 6-gate 결정 (strategy enabled / 권위 params / account / risk / kill-switch / `execution_env`). paper only |
| 9 | 런타임+BE | 트랜스포트 wiring (Redis Stream / 직접 HTTP / queue), 파이프라인 통합, retry/dedupe/observability |
| 9.5 | BE | 실 브로커 주문 / fill / 리컨실 |

런타임이 BE에 보내는 레코드는 **`SignalDetected` 단 한 종류**. `signalId`가 BE의 idempotency 입력.

---

## 5. 헬스 엔드포인트

| Method | Path | 응답 |
|---|---|---|
| GET | `/` | greeting |
| GET | `/live` | `{status:'ok'}` |
| GET | `/ready` | `{status:'ready'}` 또는 `{status:'degraded', ...}` HTTP 503 |
| GET | `/health` | 상세 (uptime, timestamp, memory, env) |

Swagger UI: `/docs`

---

## 6. 환경 변수

| Variable | Required | 비고 |
|---|---|---|
| `PORT` | no (기본 4001) | HTTP 포트 |
| `MARKET_RUNTIME_ID` | yes | 런타임 인스턴스 식별자 (unique) |
| `KIWOOM_MARKET_ENV` | yes | `mock` 또는 `production` (NODE_ENV에서 추론 금지) |
| `KIWOOM_WS_URL` | yes | WebSocket URL, hostname이 `KIWOOM_MARKET_ENV`와 매치 |
| `KIWOOM_REST_URL` | yes | REST base URL, hostname이 `KIWOOM_MARKET_ENV`와 매치 |
| `KIWOOM_APP_KEY` | optional | `start:dev` 미사용. 차트 백필에도 미사용 (lease 사용) |
| `KIWOOM_APP_SECRET` | optional | 절대 로깅 금지 |
| `KIWOOM_ACCESS_TOKEN` | Phase1 optional / verify 필수 | LOGIN payload, 로깅 금지 |
| `REDIS_URL` | optional (Phase 4.5) | 비면 in-memory, `/ready`가 degraded |
| `REDIS_LATEST_TTL_SEC` | no (기본 60) | latest 캐시 TTL |
| `REDIS_HEARTBEAT_TTL_SEC` | no (기본 30) | **반드시** `REDIS_HEARTBEAT_INTERVAL_SEC`보다 큼 (boot 검증) |
| `REDIS_HEARTBEAT_INTERVAL_SEC` | no (기본 10) | heartbeat 스케줄러 tick |
| `MARKET_RUNTIME_DATABASE_URL` | optional (Phase 5.5) | 비면 in-memory, `/ready` degraded. `market_candles` 전용 |
| `UNIVERSE_MAX_SYMBOLS_PER_GROUP` | no (기본 100) | REG 메시지당 심볼. `UNIVERSE_PER_CONNECTION_CAP` 이하여야 함 |
| `UNIVERSE_PER_CONNECTION_CAP` | mock 기본 200 / **production 필수** | production 미설정 시 부팅 거부 |
| `UNIVERSE_ACTIVE_TTL_SEC` | no (기본 86400) | active universe Redis 캐시 TTL |
| `UNIVERSE_BOOTSTRAP_FILE` | optional | dev/mock JSON 부트스트랩 경로 (production용 아님) |
| `CHART_REST_BACKFILL_CLIENT_ENABLED` | no (기본 false) | 차트 백필 클라이언트/워커 활성 |
| `CHART_REST_BACKFILL_POLL_INTERVAL_MS` | no (기본 5000, 최소 250) | 워커 poll 주기 |

mock/production은 별도 인스턴스 배포 (`KIWOOM_MARKET_ENV` 변경).

---

## 7. 데이터 흐름 종합

### 실시간 라이브 파이프라인

```
Kiwoom WS  →  KiwoomWebSocketClient  →  attachTo(pipeline)
           →  dispatchKiwoomFrame
              ├─ unknown realtimeType                → dead-letter counter
              └─ 0B trade tick
                 ├─ LatestStateCache.update         → LatestPriceWriter.write
                 │                                    ↳ Redis latest:* + INCR
                 │                                    ↳ pubsub market.{env}.latest-tick.*
                 ├─ CandleBuilder.ingest
                 │   ├─ open update                 → OpenCandlePublisher
                 │   │                                ↳ Redis open-candle:* + INCR
                 │   └─ rolledOver (closed candle)  → CandlePersistenceService.persistClosedCandle
                 │                                    ↳ Postgres market_candles UPSERT
                 │                                    ↳ pubsub market.{env}.candle-closed.*
                 │                                    ↳ open-candle key delete
```

### 차트 REST 백필 파이프라인

```
poll tick → pickup(BE)              # HMAC-signed
         → rate-limit acquire(BE)   # 거부 시 yield
         → pre-network guards       # scope / env / TTL
         → KiwoomChartRestClient.fetchCandles(closedBefore: now)
         → mapper → Phase 5.5 persistClosedCandle
         → outcome → report(BE)     # 6 typed endpoints, HMAC-signed, secret-scrubbed
```

---

## 8. Redis 키 / 채널 종합

| Surface | 키/채널 | TTL | 비고 |
|---|---|---|---|
| Latest price | `market:{env}:latest:{symbol}` | `REDIS_LATEST_TTL_SEC` | 시퀀스 stamp 포함 (7.11.1) |
| Heartbeat | `market:{env}:heartbeat:{runtimeId}` | `REDIS_HEARTBEAT_TTL_SEC` | |
| Active universe | `market:{env}:universe:active` | `UNIVERSE_ACTIVE_TTL_SEC` | |
| Subscription plan | `market:{env}:subscription:plan` | reserved | |
| Open candle | `market:{env}:open-candle:{provider}:{symbol}:{interval}` | bucket+grace | runtimeInstanceId 포함 |
| Sequence | `market:{env}:open-seq:{provider}:{symbol}:{interval}` | none | `INCR` |
| Latest-tick pubsub | `market.{env}.latest-tick.{provider}.{symbol}.{interval}` | — | |
| Candle-closed pubsub | `market.{env}.candle-closed.{provider}.{symbol}.{interval}` | — | upsert 성공 후 publish |

**`marketEnv` 세그먼트는 `assertSafeKeySegment`로 강제**. mock/production 절대 키 공유 금지.

Redis는 **실시간 캐시·트랜스포트**이지 진실의 원천 아님. Redis-only 정보는 모두 Postgres에서 복원 가능해야 함.

---

## 9. 보안 / 운영 불변식

- 토큰·시크릿·키 자료 절대 로깅 금지. `redactSecrets`가 JSON 키(`token`, `Authorization`, `app_key` …) 및 리터럴 자체를 모두 스크럽
- 캡처는 `/captures` 또는 `/.kiwoom-logs` (gitignored)
- 차트 백필 lease bundle은 메모리 전용 (Redis/PG/로그/메트릭/에러/리포트 payload 진입 금지)
- 모든 시장 파생 레코드에 `market_env` 영속
- mock/production은 Redis 키도 캔들 unique key도 공유 금지
- production cap은 operator commit (mock 측정치 상속 금지)
- production migration runner는 운영팀 결정 (auto migration 미사용)

---

## 10. 비협상 사항 (재확인)

- 런타임은 브로커 주문 직접 호출 금지
- 런타임은 `OrderIntent` 생성 금지 (draft 포함)
- 런타임은 `order/cancel/modify` Kiwoom REST 엔드포인트 호출 금지
- 런타임은 전략 파라미터 / strategy enable / universe / 계좌 리스크 / 킬스위치의 권위 소유자 아님
- 런타임은 시장 데이터 산출물 + 시그널 후보만 발행
- `market_env`는 모든 시장 파생 레코드에 영속
- 토큰·계좌 시크릿 절대 로깅 금지

---

## 11. 빌드/실행

```bash
cp .env.example .env.local
yarn install        # 또는 npm install
yarn start:dev      # 기본 4001
yarn build && yarn start:prod
yarn lint && yarn typecheck && yarn test
docker build -t trading-market-runtime .
docker run --rm --env-file .env.local -p 4001:4001 trading-market-runtime
```

검증 CLI:

```bash
KIWOOM_VERIFY_SCENARIO=register-100-tick yarn verify:kiwoom:ws
yarn verify:kiwoom:ws -- --scenario=multi-group
```
