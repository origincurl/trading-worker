# Phase 7 — Calculator Internals

> milestone: closed candle Streams → 기술지표 계산 → DB 저장 + `indicator.updated` pubsub.

## Goal
- `market.candle.closed` Redis Streams consumer-group 구독
- 받은 closed candle을 기준으로 기술지표 계산 (Phase 7 범위: SMA 20, EMA 20 두 종류)
- DB write (`indicator_1m` 테이블)
- BusPublisher.publish(`indicator.{type}.{provider}.{marketEnv}.{symbol}`)
- 부팅 시 활성 종목 indicator state 재구성 (DB에서 최근 N개 candle을 읽어 seed)
- vendor 의존성 0: 시작부터 `BrokerageModule` import 금지 (eslint + module structure로 강제)

## Phase 7 scope (in)
1. `IndicatorStreamConsumer` (trigger/consumer)
2. `IndicatorService` — rolling window 메모리 상태 + SMA/EMA 계산
3. `IndicatorRepository` — DB upsert
4. `indicator.updated.event` (BusPublisher publish)
5. CalculatorStatusService 확장

## Phase 7 scope (out, 후속 phase에서)
- 더 많은 지표 (RSI, MACD, Bollinger 등) — 별도 phase
- multi-interval (5m, 1d) — Phase 7.5
- backfill replay (Phase 6.10 backfill 결과 indicator 재계산) — 별도 phase
- 지표별 strategy 평가 (executor의 signal-detected에 가까움) — Phase 8

## 산출물

### 1. shared/event
`indicator-updated.event.ts`
```ts
export type IndicatorType = 'sma' | 'ema';

export interface IndicatorUpdatedPayload {
  provider: 'kiwoom';
  marketEnv: 'mock' | 'production';
  symbol: string;
  intervalType: '1m';
  bucketStart: string;          // closed candle bucket
  indicatorType: IndicatorType;
  windowSize: number;
  value: number | null;          // null when window not yet warm
  computedAt: string;
}
```

### 2. DB 마이그레이션
`migrations/0003_indicator_1m.sql`
- `indicator_1m(provider, market_env, symbol, bucket_start, indicator_type, window_size, value, created_at)`
- PK: `(provider, market_env, symbol, bucket_start, indicator_type, window_size)` — idempotent upsert
- 인덱스: `(symbol, indicator_type, bucket_start DESC)`

### 3. calculator 내부 계층
```
src/roles/calculator/
  calculator.module.ts                  # imports BeControlPlaneModule (no Brokerage)
  trigger/
    consumer/
      market-candle.consumer.ts         # StreamsConsumerBase impl
  usecase/
    process-closed-candle.usecase.ts    # candle event → service → repo + publish
  service/
    indicator.service.ts                # rolling window state, SMA/EMA math
    calculator-status.service.ts        # uptime, lastEventAt, indicators computed
  repository/
    indicator.entity.ts
    indicator.repository.ts             # interface
    indicator.repository.impl.ts        # TypeORM impl, no-op when DB disabled
```

### 4. 부팅 시 seed
- `IndicatorService.onApplicationBootstrap` (생략 가능 — 우선은 cold start)
- Phase 7.x에서 cold-start 시 DB에서 직전 N개 candle을 끌어와 EMA 상태 복원

### 5. 검증 체크리스트
- [ ] `ROLES=calculator` 단일 부팅 — BrokerageModule 미적재 (boot log)
- [ ] Streams `market.candle.closed` consumer-group 구독 OK
- [ ] mock closed-candle event 주입 → SMA20 / EMA20 계산 → DB row + pubsub publish
- [ ] window 부족 (예: 5번째 candle) → value=null 발행
- [ ] eslint: calculator 파일에서 `@external/brokerage` import 시 lint 실패
- [ ] typecheck/lint/build 통과

## 흐름

```
[Redis Streams: market.candle.closed]
   ↓ XREADGROUP (consumer-group: calculator)
[MarketCandleConsumer.handle]
   ↓
[ProcessClosedCandleUsecase.execute(payload)]
   ↓
[IndicatorService.update(symbol, bucketStart, close)]
   ├── SMA/EMA 계산
   └── 결과 list 반환
   ↓
[IndicatorRepository.upsert(...)]    +    [BusPublisher.publish(indicator.{...})]
```

## 비협상
- calculator 파일은 `@external/brokerage` import 금지 (eslint 룰 Phase 0에서 이미 잠금)
- indicator 계산은 deterministic — 같은 입력 → 같은 출력 (테스트 가능)
- DB write 실패 시 publish는 진행 (best-effort), 반대는 false (DB가 source of truth)

## Milestone 도달
collector가 만든 candle Streams가 calculator를 거쳐 indicator로 변환 + 영속화. BE는 indicator pubsub를 subscribe해서 FE 차트 overlay 가능. detector (Phase 9)는 indicator를 입력으로 risk 알람 발생.
