# Phase 10 — Admin HTTP (ops 전용)

> milestone: 내부망 운영자가 worker 상태를 조회하고 수동 작업을 트리거할 수 있는 HTTP endpoint 묶음.

## Goal
- 내부망 ops 컨트롤러 (BE-facing, FE 노출 절대 금지 — architecture.md §9, §13)
- 기존 `/live` `/ready` `/health`에 더해:
  - `GET /admin/info` — runtime + active roles + config 요약 (secret 제외)
  - `POST /admin/credentials/test` — BE control-plane / Kiwoom token 즉시 검증
  - `POST /admin/jobs/trigger` — 수동 작업 트리거 (예: 강제 universe refresh, dead-letter report)
  - `POST /admin/ws/reconnect` — collector/executor WS 강제 재연결
- 모든 응답은 `redactSecrets` 통과
- BasicAuth 또는 IP allowlist 가드 (Phase 10 범위: ADMIN_TOKEN env 비교)

## Phase 10 scope (in)
1. `AdminModule` (controllers + usecases, BE 규칙대로 controller → usecase → service)
2. `AdminAuthGuard` — Authorization: Bearer <ADMIN_TOKEN>
3. 4개 endpoint 위 (info / credentials.test / jobs.trigger / ws.reconnect)
4. Swagger 문서 (`/docs`) 이미 main.ts에서 활성 — admin endpoint 자동 노출
5. 모든 role module이 active일 때만 해당 admin endpoint 동작 (예: jobs.trigger는 ROLES=collector 일 때만 universe-refresh 가능)

## Phase 10 scope (out)
- 권한 등급 (operator vs admin)
- 작업 큐잉 (현재는 즉시 실행)
- audit log (Phase 11)
- OpenTelemetry tracing

## 산출물

### 1. AdminModule
```
src/admin/
  admin.module.ts                      # always-on (모든 roles에서 import)
  guard/
    admin-auth.guard.ts                # Bearer token 검증
  controller/
    admin-info.controller.ts
    admin-credentials.controller.ts
    admin-jobs.controller.ts
    admin-ws.controller.ts
  usecase/
    get-admin-info.usecase.ts
    test-credentials.usecase.ts
    trigger-admin-job.usecase.ts
    trigger-ws-reconnect.usecase.ts
  dto/
    admin-info.response.dto.ts
    test-credentials.request.dto.ts
    test-credentials.response.dto.ts
    trigger-job.request.dto.ts
    trigger-ws-reconnect.request.dto.ts
```

### 2. AdminAuthGuard
- `ADMIN_TOKEN` env (config/admin.config.ts) 가 설정되어 있으면 `Authorization: Bearer <token>` 헤더와 일치해야 통과
- 미설정 시 모든 admin endpoint 거부 (boot warning: "ADMIN_TOKEN unset — /admin/* disabled")
- `redactSecrets` ESLint guard 통과 검증

### 3. AdminInfoController
`GET /admin/info`:
```json
{
  "workerInstanceId": "...",
  "nodeEnv": "development",
  "activeRoles": ["collector"],
  "shard": null,
  "kiwoom": { "marketEnv": "mock", "wsHost": "mockapi.kiwoom.com", "restHost": "..." },
  "be": { "url": "http://localhost:4000", "mock": true },
  "uptimeSec": 12345
}
```
- secret 절대 미포함

### 4. AdminCredentialsController
`POST /admin/credentials/test`:
- body: `{ "target": "kiwoom-collector" | "kiwoom-executor" | "be-control-plane" }`
- 응답: `{ "ok": boolean, "detail": string }`
- 실제 token issue / BE ping 수행

### 5. AdminJobsController
`POST /admin/jobs/trigger`:
- body: `{ "job": "universe-refresh" | "candle-flush" | "chart-backfill-poll" | "alert-eval" }`
- 비활성 role의 job 요청 시 200 + `{ triggered: false, detail: "role=... not active" }`
- 응답: `{ "triggered": boolean, "detail": string }`
- 구현: `ModuleRef.get(class, { strict: false })`로 role usecase/scheduler를 lazy-resolve. AdminModule이 role module을 import하지 않으면서도 동작 (role 격리 유지)

### 6. AdminWsController
`POST /admin/ws/reconnect`:
- body: `{ "profile": "collector" | "executor" }`
- gateway.disconnectMarketDataStream → 재연결은 Phase 6.8 orchestrator가 자동 처리

## 검증 체크리스트
- [x] `ADMIN_TOKEN` 미설정 시 /admin/* 401
- [x] 잘못된 Bearer 401
- [x] 올바른 Bearer + /admin/info → 200 + secret 미포함
- [x] 비활성 role 작업 트리거 시 200 + `triggered: false`
- [x] swagger `/docs` 에 admin tag 노출
- [x] typecheck/lint/build 통과

## 비협상
- FE 절대 호출 금지 (architecture.md §13) — ingress에서 `/admin/*` 차단
- secret 응답 금지 (`redactSecrets` 통과)
- DML 발급 금지 (read-only 또는 trigger-only)

## Milestone 도달
운영자가 worker pod에 직접 들어가지 않고도 헬스 / credential / job trigger 수행. 다음 단계는 Phase 11 (deploy + migrations + tests).
