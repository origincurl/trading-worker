# NestJS BE 데이터 모델 계층 정의

## 1. 아키텍처 구조
- controller > usecase > service > repository/gateway
- repository: interface + impl 필수 (DB 접근)
- gateway: interface + impl 필수 (외부 시스템 접근)
- apiClient: vendor 별 raw API 호출 (gateway impl 내부에서만 사용)

### External Integration Naming Rule
- `Repository` : DB 접근
- `Gateway` : 외부 시스템 접근 (도메인 추상화 인터페이스)
- `ApiClient` : vendor 별 raw API 호출
- `Contract` : vendor 별 request/response 타입

Examples:
- `UserRepository`
- `BrokerageGateway`, `MailGateway`, `SmsGateway`, `MessageGateway`

Vendor implementations:
- `KisBrokerageGateway`, `KiwoomBrokerageGateway`
- `SendgridMailGateway`, `AligoSmsGateway`

Raw API clients:
- `KisApiClient`, `KiwoomApiClient`, `SendgridApiClient`, `AligoApiClient`

Call flow:
- Service
  - XxxGateway (interface)
    - VendorXxxGateway (impl)
      - VendorApiClient
        - External API

### External folder structure rule
- `external/{domain}/gateway`: gateway interface 위치
- `external/{domain}/vendors/{vendor}`: vendor 별 gateway impl, apiClient, contract 위치
- gateway interface만 `gateway` 폴더에 둔다.
- vendor gateway 구현체는 각 vendor 폴더 하위에 둔다.
- apiClient는 각 vendor 폴더 하위에 둔다.
- contract는 vendor 종속 타입이므로 각 vendor 폴더 하위에 둔다.
- client, contract를 external 밖으로 분리하지 않는다.
- vendor 종속 구현은 반드시 `vendors/{vendor}` 하위에 모은다.

Recommended:
- external
  - brokerage
    - gateway
      - brokerage.gateway.ts
    - service
      - brokerage.service.ts
      - brokerage-gateway.resolver.ts
    - vendors
      - kiwoom
        - contract
          - request
          - response
        - kiwoom-brokerage.gateway.ts
        - kiwoom.api-client.ts
      - korea-invest
        - contract
          - request
          - response
        - korea-invest-brokerage.gateway.ts
        - korea-invest.api-client.ts
    - brokerage.module.ts
    - brokerage.token.ts
- 예외: token, jwt, env, password hash, verification code, util성 helper service 등은 별도 계층으로 둬서 여기저기 쓸 수 있음
  - repository/gateway에 의존하지 않는 stateless utility 성격의 service 는 service > service 호출이 허용된다.
  - repository/gateway에 의존하지 않는 stateless 비즈니스 정책/검증 service 도 service > service 호출이 허용된다.
  - 예: PasswordService, JwtTokenService, VerificationCodeService, OperationRequestService, AccountCredentialPolicyService, -PolicyService, -ValidatorService

## 2. 계층별 역할

## controller
HTTP 요청을 받는 진입 계층

### 역할
- Request DTO 검증
- usecase 만 호출
- 비즈니스 로직은 작성하지 않음

### 사용 모델
- dto

## usecase
하나의 API 또는 사용자 행위 단위의 흐름을 담당하는 계층

### 역할
- controller와 service 사이의 애플리케이션 로직 처리
- service 만 호출
- request dto를 잘 분리해서 service 에 호출
  - 필요시 파싱 진행
- service에서 받은 model을 response dto로 변환

### 사용 모델
- dto
- model

## service
도메인 중심의 핵심 비즈니스 로직을 담당하는 계층

### 역할
- 내부 model 기준으로 비즈니스 로직 처리
- repository, gateway 만 호출
- 너무 여러 repository, gateway 호출하는건 피하기 (조합하는 것은 usecase가 주로 한다.)
- repository interface를 통해 DB 데이터 사용
- gateway interface를 통해 외부 시스템 데이터 사용
- repository/gateway에 의존하지 않는 정책/검증 service 호출은 허용한다.

### 사용 모델
- model

## repository
persistent layer 전용 계층

### 역할
- DB 저장, 조회, 수정, 삭제 처리
- repository interface는 model 기준으로 정의
- repository impl 내부에서 model과 entity 변환
- entity를 repository 외부로 노출하지 않음
- Partial 필요시 적극적으로 사용
- update를 하나하나 만들지 않음 (Partial 로 구성한 함수 하나로 거의 통일)

### 사용 모델
- model
- entity

## gateway
외부 시스템 연동 전용 계층 (도메인 관점의 추상화)

### 역할
- 외부 시스템 호출의 도메인 추상화 (vendor 무관한 인터페이스 제공)
- gateway interface는 model 기준으로 정의 (vendor 종속 타입 노출 금지)
- vendor 구현체(`KisBrokerageGateway`, `SendgridMailGateway` 등)에서 실제 vendor 선택/호출
- vendor 구현체 내부에서 `XxxApiClient` 를 호출
- vendor 구현체 내부에서 contract ↔ model 변환
- contract를 gateway 외부로 노출하지 않음
- gateway interface는 `external/{domain}/gateway` 하위에 둔다.
- gateway vendor 구현체는 `external/{domain}/vendors/{vendor}` 하위에 둔다.

### 사용 모델
- model
- contract (vendor 구현체 내부에서만)

## apiClient
vendor 별 raw API 호출 전용 계층

### 역할
- 외부 API 호출 (HTTP/SDK)
- 외부 API 인증 처리 (토큰 발급/갱신 등)
- 외부 응답 파싱 (contract 단위로 반환)
- vendor 마다 1:1 로 존재 (`KisApiClient`, `KiwoomApiClient`, ...)
- gateway 의 vendor 구현체에서만 호출
- service/usecase/controller 에서 직접 호출 금지

### 위치
- `external/{domain}/vendors/{vendor}` 하위에 둔다.

### 사용 모델
- contract

## 3. 데이터 모델 계층

## dto
- 각 도메인 하위 dto 폴더 안에 둔다.
- 클래스 이름에는 Dto를 붙이지 않고 반드시 뒤에 Request, Response를 붙인다.
- dto/request/- : request dto
  - model로 바꿔야 할 때는 반드시 각 모델별로 별도 mapper 파일을 만들고 변환 함수를 선언한다.
  - Model.fromDto(dto) 사용
- dto/response/- : response dto
  - Response.fromModel(model) 사용
  - response dto 파일에 static 으로 포함시킨다.

## model
서비스 내부에서 사용하는 메인 데이터 계층

### 규칙
- src/model/- 에 위치한다.
- 이름.model.ts 로 선언한다.
- model 클래스 이름에 반드시 Model 붙이기
- model 클래스 파일에는 기본적인 파싱 함수 외 복잡한 로직을 넣지 않음
- dto를 model로 바꿀 때는 반드시 별도 "이름.mapper.ts" 파일에 변환 함수를 둔다.
- mapper는 src/mapper/- 에 둔다.

## entity
DB table 정의용 데이터 구조

### 역할
- ORM 매핑
- DB 컬럼 정의
- DB 관계, 인덱스, 제약 조건 표현
- persistence layer 전용 모델

### 규칙
- entity 클래스 이름에 반드시 Entity 붙이기
- repository impl 에서만 사용
- controller, usecase, service로 노출하지 않음
- repository impl에서 model과 entity를 변환
  - interface 에서는 model 밖에 안보임
- 반드시 toModel 함수 포함하기

## contract
vendor 별 API 전용 데이터 구조

### 역할
- vendor API request 구조 표현
- vendor API response 구조 표현
- 외부 시스템과의 계약 구조 표현

### 규칙
- request/response 분리
  - external/{domain}/vendors/{vendor}/contract/request/-
  - external/{domain}/vendors/{vendor}/contract/response/-
- contract 클래스 이름에 반드시 RequestContract/ResponseContract 붙이기
- apiClient 와 gateway 의 vendor 구현체에서만 사용
- controller, usecase, service 로 노출하지 않음
- gateway 의 vendor 구현체에서 contract ↔ model 변환
  - gateway interface 에서는 model 밖에 안보임
- response contract는 필요시 toModel 함수 포함하기
- request contract는 필요시 model/input 기반 생성 함수를 둘 수 있음

# 파일 규칙
- controller: 역할이 다르거나 path가 다르면 파일 분리 (너무 큰 controller 피하기, 그렇다고 너무 작게작게는 별로)
- usecase: 파일 하나에 usecase 하나 (execute 함수는 반드시 한개만 있음, 필요시 private 함수 존재 가능)
- service: 파일 하나에 service 하나 (다양한 repository, gateway 호출 피하기)
- repository: 파일 하나에 repository 하나
- gateway: 파일 하나에 gateway 하나 (interface, vendor 구현체 각각 별도 파일)
  - interface는 external/{domain}/gateway 하위에 둔다.
  - vendor 구현체는 external/{domain}/vendors/{vendor} 하위에 둔다.
- apiClient: 파일 하나에 apiClient 하나 (vendor 1:1)
  - external/{domain}/vendors/{vendor} 하위에 둔다.
- dto: 파일 하나에 dto 하나 (필요시 fromModel 함수 소유 가능)
- model: 파일 하나에 model 하나
- mapper: 같은 Model을 사용하는 것은 같은 파일로 뭉치기 (ex: account.mapper.ts > requestDto를 AccountModel 로 만드는 변환 함수들 보유)
- entity: 파일 하나에 entity 하나
- contract: 파일 하나에 contract 하나
  - external/{domain}/vendors/{vendor}/contract/request/-
  - external/{domain}/vendors/{vendor}/contract/response/-

# 환경 변수 규칙
- env 내부 값은 언제나 UPPER_CASE 로 한다
  - ex: `DATABASE_URL`, `JWT_SECRET`, `KIWOOM_APP_KEY`
- 단어 구분은 `_` (snake-upper)
- `.env`, `.env.local`, 코드 내 `process.env.XXX` 모두 동일 규칙