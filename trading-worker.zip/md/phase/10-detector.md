# Phase 9 — Detector Internals

> milestone: collector dead-letter / 시장 데이터 이상 / 시스템 상태 ⇒ 임계 초과 시 NotifyGateway로 알람 발송 + `alert.raised` Streams 발행.

## Goal
- vendor 의존성 0 (calculator와 동일)
- 다중 트리거 (scheduler + Streams consumer)
- 임계값 평가 → NotifyGateway (slack/email/sms) 호출
- DB write (`alert_raised` 테이블) + Streams `alert.raised` (BE audit)

## Phase 9 scope (in)
1. `AlertEvaluator` — Phase 9 범위 룰:
   - **stale-tick**: collector의 lastTickAt이 N초 이상 정지 (체크는 Phase 9에서 DB 쿼리 없이 collector의 Redis hash 기반 또는 단순 sentinel)
   - **dead-letter spike**: 1분간 N건 초과 dead-letter (collector_dead_letter 테이블 query)
   - **order rejection spike**: order_attempt 중 status=failed가 1분간 N건 (order_attempt 테이블 query)
2. `AlertScheduler` — 1분 주기로 모든 룰 평가
3. `AlertService` — 알람 dedup (open alert window), Notify 호출, DB + Streams 송신
4. `AlertRepository` — `alert_raised` 영속화
5. DetectorStatusService 확장

## Phase 9 scope (out, 후속)
- 알람 ack / close 라이프사이클 (operator UI)
- multi-channel routing 룰 (severity 별 slack vs sms)
- ML 기반 anomaly threshold 학습
- 알람 storm 억제 (rate limit per category)

## 산출물

### 1. shared/event
`alert-raised.event.ts` — Streams 페이로드:
```ts
export interface AlertRaisedPayload {
  alertId: string;
  category: 'dead-letter-spike' | 'order-rejection-spike' | 'stale-tick';
  severity: 'info' | 'warning' | 'critical';
  subject: string;
  message: string;
  metadata?: Record<string, string>;
  raisedAt: string;
}
```
- Streams: `alert.raised`
- consumer-group dedup: `alertId`

### 2. DB 마이그레이션
`migrations/0006_alert_raised.sql`
- `alert_raised(id, alert_id UNIQUE, category, severity, subject, message, metadata JSONB, raised_at, worker_instance_id, ...)`
- 인덱스: `(category, raised_at DESC)`

### 3. detector 내부 계층
```
src/roles/detector/
  detector.module.ts                  # imports NotifyModule + BeControlPlaneModule
  trigger/
    scheduler/
      alert-eval.scheduler.ts         # 60s 주기 평가
  usecase/
    evaluate-alerts.usecase.ts        # 룰 평가 + AlertService.raise() 호출
  service/
    alert.service.ts                  # dedup + notify + repo + streams
    alert-evaluator.service.ts        # 룰 평가 로직
    detector-status.service.ts
  repository/
    alert-raised.entity.ts
    alert.repository.ts
```

### 4. dedup 정책 (Phase 9 기본)
- (`category`, `subject_key`) 별 in-memory open-alert map
- 같은 (category, subject_key)로 일정 윈도우(예: 5분) 내 raise 시 skip
- 5분 경과 후 동일 카테고리 재발생 시 다시 raise (escalation은 Phase 9.x)

### 5. NotifyGateway 호출
- `severity='info'` → slack info channel
- `severity='warning'` → slack warning channel
- `severity='critical'` → slack critical + sms (env로 라우팅)
- channel은 NotifyModule이 이미 vendor 라우팅 처리 — detector는 NotifyInput만 전달

### 6. BE audit 호출
- `BeControlPlaneClient.reportAlertRaised` 호출 (이미 Phase 4에 존재)
- 실패해도 알람 자체는 진행 (best-effort)

## 검증 체크리스트
- [ ] `ROLES=detector` 부팅 → BrokerageModule **미적재** (보안 격리)
- [ ] mock notify gateway에 raise() 호출 → log 확인
- [ ] dedup 동작: 1분 내 같은 (category, subject) 두 번 raise 시 한 번만 notify
- [ ] `alert.raised` Streams entry + DB row 모두 작성
- [ ] BE.reportAlertRaised 호출 (mock log)
- [ ] eslint: detector → `@external/brokerage` import 시 실패
- [ ] typecheck/lint/build 통과

## 흐름

```
[AlertScheduler 1m tick]
   ↓
[EvaluateAlertsUsecase.execute]
   ↓
[AlertEvaluator.evaluate*]                    # 룰별 평가, AlertCandidate[] 반환
   ↓
[AlertService.raise(candidate)]
   ├── dedup window 체크 → 통과시 진행
   ├── DB INSERT alert_raised (idempotent on alertId)
   ├── NotifyGateway.notify(...)              # slack/email/sms
   ├── BUS_STREAMS.produce('alert.raised')
   └── BE.reportAlertRaised(...)              # audit hook
```

## 비협상
- detector는 `@external/brokerage` import 금지 (eslint guard 활성 — Phase 0 룰)
- 알람 메시지에 token/secret 포함 금지 (`redactSecrets` 통과)
- NotifyGateway 호출 실패 시 worker 정지 금지 — degraded 모드로 진행

## Milestone 도달
운영자가 worker 헬스 / vendor 이상 / 주문 거부를 사후 발견하지 않고 실시간 알람으로 인지. Phase 9 이후 worker 단독 운영 신뢰성 도달.
