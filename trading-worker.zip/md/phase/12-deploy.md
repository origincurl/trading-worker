# Phase 11 — Deploy (Docker / migrations / tests)

> milestone: 한 image, ROLES env로 N개 deployment, migration 절차 표준화, baseline 테스트.

## Goal
- 동일 docker image로 collector / calculator / executor / detector / multi-role 배포
- 수동 SQL migration 적용 절차 + 검증 스크립트 (`yarn migrate:run`)
- Jest baseline: dispatcher / event-mapper / candle-builder / indicator / alert-evaluator 단위 테스트
- CI 친화: `yarn typecheck && yarn lint && yarn test && yarn build` 한 줄
- mock / production 배포 격리 가이드 (env 혼용 금지)

## Phase 11 scope (in)
1. multi-stage `Dockerfile` (builder → runtime)
2. `.dockerignore`
3. `docker-compose.dev.yml` — Postgres + Redis 로컬 실행, 4 role 분리 컨테이너
4. migration runner — `scripts/migrate.ts` (psql 또는 pg client로 `migrations/*.sql` 순서 적용)
5. baseline tests:
   - `src/roles/collector/mapper/kiwoom-tick.event-mapper.spec.ts`
   - `src/roles/collector/service/candle-builder.service.spec.ts`
   - `src/roles/calculator/service/indicator.service.spec.ts`
   - `src/roles/detector/service/alert-evaluator.service.spec.ts`
6. `README.md` 운영 섹션 추가 (build, run, deploy, migrate, debug)
7. GitHub Actions workflow (선택)

## Phase 11 scope (out)
- k8s manifest (Helm/Kustomize) — repo 외부
- 모니터링 (Prometheus exporter) — Phase 12+
- 보안 스캔 (snyk, trivy) — CI 파이프라인 별도
- 무중단 배포 시퀀스 (graceful drain)

## 산출물

### 1. Dockerfile (multi-stage)
- builder stage: node:20-alpine + yarn install + nest build
- runtime stage: node:20-alpine + dist/ + node_modules (production-only)
- CMD `node dist/main`
- ENV로 ROLES 등 주입
- USER non-root

### 2. docker-compose.dev.yml
- services: postgres, redis, worker-collector, worker-calculator, worker-executor, worker-detector
- 각 worker는 동일 image, ROLES env만 다름
- postgres healthcheck로 worker 컨테이너 부팅 순서 보장
- migration 컨테이너 (`worker-migrate`) — postgres ready 후 1회 실행

### 3. scripts/migrate.ts
- `WORKER_DATABASE_URL` 사용
- `migrations/*.sql` 사전순 정렬 후 차례로 실행
- `schema_migrations(filename, applied_at)` 테이블에 적용 이력 기록 (없으면 자동 생성)
- 이미 적용된 파일은 skip
- 실패 시 transaction rollback + 명확한 에러 메시지

### 4. baseline tests
- 각 spec은 input/expected 명확. 외부 의존성(DB/Redis) 없음 — pure compute.
- 커버리지 목표: collector mapper/builder, calculator indicator, detector evaluator 100%
- 향후 phase에서 추가될 spec의 패턴 정착

### 5. package.json 스크립트
- `migrate:run`: `ts-node scripts/migrate.ts`
- `start:prod`: 이미 존재
- 별도 `docker:build`, `docker:up` (선택)

## 검증 체크리스트
- [ ] `docker build` 성공, 이미지 크기 < 250MB (alpine + dist만)
- [ ] `docker compose -f docker-compose.dev.yml up` 으로 4 role 모두 부팅
- [ ] migration 컨테이너가 postgres에 schema 6개 테이블 생성
- [ ] worker 컨테이너에서 `/health` 응답
- [ ] `yarn test` 모든 spec 통과
- [ ] `yarn typecheck && yarn lint && yarn build && yarn test` 한 줄 통과

## 비협상
- production 이미지에 `.env.local` / `KIWOOM_ACCESS_TOKEN` 등 secret 포함 금지 (.dockerignore 강제)
- migration은 자동 실행 금지 (worker boot path에서 schema 변경 금지). 별도 스크립트로만 실행
- mock / production은 별도 image tag 사용 권장 (예: `:mock-1.0.0` vs `:prod-1.0.0`)

## Milestone 도달
worker 코드가 4개 role 전부 배포 가능한 상태로 완성. trading-be와의 통합 / k8s manifest는 별도 repo로 분리. 이후는 운영 + 성능 튜닝 + 추가 indicator/alert 룰의 점진적 확장.
