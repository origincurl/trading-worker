# Phase 8 — Executor Internals

> milestone: signal BullMQ job → 주문 placement (Kiwoom REST) → 체결 stream subscribe (WS) → `order.filled` Streams 발행.

## Goal
- BullMQ queue `signal.detected` consumer (architecture.md §8)
- Job payload (BE-issued `signal-detected` envelope) → `PlaceOrderUsecase` → `KiwoomBrokerageGateway.placeOrder`
- Kiwoom WS 체결 stream subscribe — Phase 6 패턴 재사용, 단 EXECUTOR_BROKERAGE_GATEWAY + 체결 frame type
- 체결 event를 Redis Streams `order.filled`로 produce
- BE control-plane으로 `reportSignalDetected` / `reportOrderFilled` 호출
- order DB row 영속화 (`order_attempt` 테이블)

## Phase 8 scope (in)
1. `SignalDetectedQueueConsumer` (BullMqProcessorBase)
2. `PlaceOrderUsecase` — payload validation, idempotency, gateway 호출
3. `ExecutorOrderService` — DB write + `reportOrderFilled` BE 호출
4. `KiwoomExecutionSubscriber` — vendor WS 체결 stream (`order-fill` real type)
5. `IngestOrderFillUsecase` — frame → normalized OrderFillModel → repo + Streams
6. ExecutorStatusService 확장

## Phase 8 scope (out, 후속)
- 주문 수정/취소 (`CancelOrderUsecase` / `ModifyOrderUsecase`)
- multi-leg / bracket / OCO 주문
- position rebuild (체결 stream 누락 시 REST로 backfill)
- rate-limit 최적화 (executor 프로필은 이미 RateLimiter 분리)

## 산출물

### 1. shared/event
- `order.filled.event.ts` — Streams payload (`OrderFilledPayload`): `(provider, marketEnv, accountId, vendorOrderId, clientOrderId, symbol, side, filledQty, filledPrice, filledAt)`
- consumer-group dedup: `vendorOrderId`

### 2. DB 마이그레이션
`migrations/0004_order_attempt.sql` + `0005_order_fill.sql`:
- `order_attempt(id, provider, market_env, account_id, client_order_id, symbol, side, type, quantity, price, status, vendor_order_id, created_at, ...)`
- PK 또는 unique: `(provider, market_env, client_order_id)` — Phase 8 idempotency 핵심
- `order_fill(id, provider, market_env, account_id, vendor_order_id, client_order_id, symbol, side, filled_qty, filled_price, filled_at, raw_payload_jsonb, created_at)`
- unique: `(provider, market_env, vendor_order_id)`

### 3. executor 내부 계층
```
src/roles/executor/
  executor.module.ts                # imports BrokerageModule + BeControlPlaneModule
  trigger/
    consumer/
      signal-detected.consumer.ts   # BullMQ
    subscriber/
      kiwoom-execution.subscriber.ts # WS 체결 stream
  usecase/
    place-order.usecase.ts
    ingest-order-fill.usecase.ts
  service/
    executor-order.service.ts
    executor-status.service.ts
  mapper/
    kiwoom-order-fill.event-mapper.ts
  repository/
    order-attempt.entity.ts
    order-fill.entity.ts
    order.repository.ts             # interface + impl
```

### 4. 신호 → 주문 흐름
```
BE → BullMQ.queue('signal.detected', { signalId, accountId, ... })
         ↓
[SignalDetectedQueueConsumer]
         ↓ jobId = signalId (idempotent enqueue)
[PlaceOrderUsecase.execute]
         ↓ DB INSERT order_attempt (status=pending)
[EXECUTOR_BROKERAGE_GATEWAY.placeOrder]
         ↓ Kiwoom REST 응답에서 vendorOrderId 수신
[ExecutorOrderService.markAccepted(vendorOrderId)]
         ↓ DB UPDATE order_attempt
[BE.reportSignalDetected]   ← (선택, BE에 audit)
```

### 5. 체결 → fan-out 흐름
```
[Kiwoom WS 체결 stream]
         ↓
[KiwoomExecutionSubscriber.handleFrame]
         ↓
[KiwoomOrderFillEventMapper.fromFrame]
         ↓
[IngestOrderFillUsecase.execute]
         ├── DB INSERT order_fill (idempotent on vendorOrderId)
         ├── BUS_STREAMS.produce('order.filled', event)
         └── BE.reportOrderFilled
```

### 6. idempotency
- BullMQ `jobId = signalId`: 동일 시그널 재발행 시 같은 job
- DB unique on `(provider, market_env, client_order_id)` for order_attempt
- DB unique on `(provider, market_env, vendor_order_id)` for order_fill
- Streams produce는 dedup 없음 (consumer-group이 dedup하면 됨)

### 7. ExecutorStatusService 확장
- `signalsProcessed=N ordersPlaced=N ordersRejected=N fills=N`
- `wsConnected`, `lastFillAt`, `lastSignalAt`

## 검증 체크리스트
- [ ] `ROLES=executor` 부팅 시 collector keys 사용 안 됨 (assertProfile guard 통과)
- [ ] BullMQ job 주입 → order_attempt row 생성 → KiwoomBrokerageGateway.placeOrder 호출
- [ ] 동일 signalId 두 번 enqueue → 두 번째는 BullMQ가 dedupe (1개 row만)
- [ ] mock execution frame 주입 → order_fill row + `order.filled` Streams entry
- [ ] BE reportOrderFilled 호출 OK (mock BE log 확인)
- [ ] eslint: executor 파일이 다른 role import 시 실패
- [ ] typecheck/lint/build 통과

## 비협상
- executor key는 collector key와 절대 공유 금지 (이미 brokerage.token.ts에서 분리, 부팅 시 키 비교 가드)
- 주문 토큰/credential은 로깅 금지 (`redactSecrets` 강제)
- 신호는 주문 인텐트가 아님 — `signal.detected` payload에 `quantity/price` 직접 사용 금지. BE 정책이 변환한 값을 사용
- 체결 stream 누락 → Phase 8.x에서 REST polling으로 보강 (Phase 8 본 범위 out)

## Milestone 도달
신호 → 주문 → 체결 한 줄기가 완성. BE는 `order.filled` Streams를 consumer-group으로 구독해 audit / portfolio 업데이트 가능. 다음 단계는 detector(Phase 9)에서 위험 감지.
