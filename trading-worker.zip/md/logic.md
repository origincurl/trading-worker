worker 프로젝트를 만들꺼야
fe, be 모두 typescript, node 기반이라서

nest로 개발하려는데 적합한지 판단해줘

# worker 기능
- 주식 및 장 및 여러 정보를 정기적으로 3party api를 통해 불러온뒤 저장한다. (collector)
- 저장된 정보를 기반으로 지표로 연산하여 저장한다. (calculator)
- 전략 기준 + 정보 + 지표 를 조합하여 결정을 생성한다. (executor)
    - 결정은 때로 주문을 만들고 체결 결과에 따라 추가 동작을 한다.
- 리스크 기준 + 정보 + 지표 를 조합하여 경보를 생성한다. (detector)
    - 경보에 따라 3party api를 호출한다.

# worker 특이사항
- calculator, detector는 증권사 vender와 관계 X
- collector, executor는 증권사 vender와 관계 O
    - 증권사는 rate limit 있으니 executor 전용 key는 반드시 분리 필요


# 분리/다중 배포 가능성
- 성능이나 부하에 맞춰 각 역할(4종류) 단위로 분리해서 배포할수도 있어
- 한 팟에 역할 하나만 배포할수도 있고 여러개를 합쳐서 배포할수도 있고
- 역할 하나를 여러 팟에 배포하여 연산을 분산할수도 있어


# FE 기능
- auth, user 관리
- account 관리
    - account-credential 관리
        * 각 vender, 모의 여부 마다 양식이 다름
        - 기록, 테스트 등 기능 필요
- channel 관리
    * 각 vender 마다 양식이 다름
- strategy, risk 관리
    - master(템플릿), account(스냅샷) 개념으로 관리
- 현재 시장 상황 관리 (실시간)
    - 소켓 통신
    - collector worker가 소켓으로 전달
- 자산 상황 관리 (실시간)
    - 소켓 통신
    - executor worker가 소켓으로 전달

- 실시간 주문, 체결 관리 (실시간)
    - 소켓 통신
    - executor worker가 소켓으로 전달

- 그 외 기록 자료 관리
    - 추이, 체결 기록 등등 다양한 내용들 포함