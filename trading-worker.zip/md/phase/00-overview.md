# Worker Project — Phase Overview

> [architecture.md](../architecture.md) 기준 구현 로드맵. 진행 상황은 각 phase 문서에 기록.

---

## 진행 원칙
- 각 phase는 **컴파일 가능 + 부팅 가능** 상태로 끝낸다. 깨진 상태로 다음 phase 진입 금지.
- Phase 0~5 = "전체 구조 milestone". 4개 role module이 모두 존재하고 `ROLES` env로 선택 부팅 가능한 상태.
- Phase 6~9 = role 별 내부 로직 채우기. 독립적으로 진행 가능.
- 외부 시스템(BE, Kiwoom) 미준비 시 stub/mock으로 통과, 실제 연동은 별도 사이클.

## Milestone 표

| Phase | 목표 | 상태 | 문서 |
|---|---|---|---|
| 0 | Project scaffold | pending | [01-scaffold.md](./01-scaffold.md) |
| 1 | Config + Common + Health + Main | pending | [02-config-common-health.md](./02-config-common-health.md) |
| 2 | Shared infra (persistence/cache/bus/event) | pending | [03-shared-infra.md](./03-shared-infra.md) |
| 3 | External: Brokerage gateway (Kiwoom) | pending | [04-brokerage-gateway.md](./04-brokerage-gateway.md) |
| 4 | External: BE control-plane + Notify gateway | pending | [05-be-and-notify.md](./05-be-and-notify.md) |
| 5 | 4 role skeletons | done | [06-role-skeletons.md](./06-role-skeletons.md) |
| ※ | **— Structure milestone 도달 —** | | |
| 6 | Collector: tick ingest (WS → live pubsub) | done | [07-collector.md](./07-collector.md) |
| 6.5 | Collector: orderbook (0D) | done | [07.5-collector-orderbook.md](./07.5-collector-orderbook.md) |
| 6.6 | Collector: 1m candle builder + persistence | done | [07.6-collector-candles.md](./07.6-collector-candles.md) |
| 6.7 | Collector: BE universe lease (dynamic symbols) | done | [07.7-collector-universe.md](./07.7-collector-universe.md) |
| 6.8 | Collector: WS reconnect + tick rejection 견고화 | done | [07.8-collector-reconnect.md](./07.8-collector-reconnect.md) |
| 6.9 | Collector: dead-letter Streams + monitoring | done | [07.9-collector-dead-letter.md](./07.9-collector-dead-letter.md) |
| 6.10 | Collector: chart backfill (REST historical) | done (stub) | [07.10-collector-chart-backfill.md](./07.10-collector-chart-backfill.md) |
| 7 | Calculator internals | done | [08-calculator.md](./08-calculator.md) |
| 8 | Executor internals | done | [09-executor.md](./09-executor.md) |
| 9 | Detector internals | done | [10-detector.md](./10-detector.md) |
| 10 | Admin HTTP | done | [11-admin-http.md](./11-admin-http.md) |
| 11 | Docker / migration / tests | done | [12-deploy.md](./12-deploy.md) |

## 의존성 그래프 (대략)

```
0 → 1 → 2 ─┬─→ 3 ─┐
           └─→ 4 ─┴─→ 5 ─┬─→ 6 → 6.5 → 6.6 → 6.7 → 6.8 → 6.9 → 6.10 ─┐
                        ├─→ 7                                        │
                        ├─→ 8                                        ├──→ 10 → 11
                        └─→ 9 ───────────────────────────────────────┘
```

- 6.x 시퀀스는 collector를 한 책임씩 얹는 점진적 빌드업. 각 단계 끝나면 booting + smoke test 가능
- 6.6 (candle persistence)는 7 (calculator)의 사실상 필수 입력
- 6.7 (BE universe)은 6.x 중에서 가장 BE 의존 큼 — BE 미준비 시 mock 사용
- 8 (executor), 9 (detector)는 5 완료 후 6.x과 병렬 가능
- 10 (admin)은 1 직후에도 가능하지만 role 작업 후가 자연스러움

## 외부 의존 가정

| 시스템 | 가정 | 우회책 |
|---|---|---|
| trading-be control-plane | credential lease / signal report endpoint 존재 | mock stub 클라이언트 작성, response 시뮬레이션 |
| Kiwoom WS/REST | mock 서버 가용 (`.env.local` 기준) | dry-run / capture replay |
| Postgres | trading-be가 쓰는 RDS 공유 (`MARKET_RUNTIME_DATABASE_URL`) | worker는 자기 테이블만 소유 |
| Redis | localhost 6379 | in-memory fallback (Phase 2 이후) |

## 비협상 (architecture.md 재확인)

- FE 직접 통신 금지
- collector key ≠ executor key
- calculator / detector는 external/vendor import 금지 (compile-time check)
- mock / production 프로세스 분리
- 모든 비밀 값 로깅 금지 (`redactSecrets` 강제)
